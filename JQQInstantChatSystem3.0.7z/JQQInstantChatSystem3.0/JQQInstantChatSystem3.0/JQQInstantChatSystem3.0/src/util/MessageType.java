package util;

/**
 * @author MuGe
 * @date 创建时间: 2019年6月24日 上午9:19:54
 * @version V1.0
 * @Project JQQInstantChatSystem3.0
 * @Package util
 */
/*
 * 定义包的种类
 */
public interface MessageType {
	String message_succeed = "1";// 表明登录成功
	String message_login_fail = "2";// 表明密码错误
	String message_user = "3";// 表明用户不存在,无法登录
	String message_register = "4";// 表明用户不存在可以注册
	String message_register_fail = "5";// 表明用户存在,无法注册
	String message_comm_mes = "6";// 普通信息包
	String message_get_onLineFriend = "7";// 要求在线好友的包
	String message_ret_onLineFriend = "8";// 返回在线好友的包
	String Message_group = "9";// 群消息的包

}
