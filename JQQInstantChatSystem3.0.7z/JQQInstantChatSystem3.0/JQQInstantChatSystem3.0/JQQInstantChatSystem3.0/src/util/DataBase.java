package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import qq.mode.User;

//业务逻辑层

public class DataBase {

	// 数据库驱动
	public static final String DRIVER = "";
	// 数据库连接URL
	public static final String URL = "";
	// 数据库登陆用户名
	public static final String DBNAME = "";
	// 数据库登陆密码
	public static final String DBPASS = "";

	private Connection conn = null;
	private PreparedStatement pstat = null;
	private ResultSet rs = null;

	// 创建数据库的连接
	public Connection getConn() throws ClassNotFoundException, SQLException {

		// 加载驱动程序类
		Class.forName(DRIVER);
		// 得到连接对象
		conn = DriverManager.getConnection(URL, DBNAME, DBPASS);

		return conn;

	}

	// 释放资源
	public void closeAll() {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (pstat != null) {
			try {
				pstat.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// 根据用户名查找用户对象的方法
	public User getUserByName(String Id) {

		try {
			conn = this.getConn(); // 建立连接
			String sql = "select * from tbl_user where Username=?";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, Id);
			rs = pstat.executeQuery();
			User u = null;
			// 把结果集包装成用户对象
			while (rs.next()) {
				u = new User();
				u.setID(rs.getInt(""));
				u.setPassword(rs.getString(""));
			}
			return u;

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} finally {
			this.closeAll();
		}

	}

}
