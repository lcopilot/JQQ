package util;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Random;

public class Verificationcode {
	// 候选字符集
	private static final char[] chars = ("0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM")
			.toCharArray();
	// 字符数量
	private static final int SIZE = 4;
	// 图片宽度
	private static final int WIDTH = 160;
	// 图片高度
	private static final int HEIGHT = 40;
	// 字体大小
	private static final int FONT_SIZE = 30;
	// 干扰线的个数
	private static final int LINES = 5;

	// 生成随机验证码及图片
	public static Object[] createImage() {
		// 存储产生的随机数
		StringBuffer sb = new StringBuffer();
		// 存储验证码图片
		BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
		// 获取画笔
		Graphics g = image.getGraphics();
		// 设置画笔颜色
		g.setColor(Color.LIGHT_GRAY);
		// 绘制矩形
		g.fillRect(0, 0, WIDTH, HEIGHT);
		// 画随机字符
		Random r = new Random();
		for (int i = 0; i < SIZE; i++) {
			// 随机字符的索引
			int n = r.nextInt(chars.length);
			// 设置画笔的颜色
			g.setColor(Color.blue);
			// 设置字体大小
			g.setFont(new Font(null, Font.BOLD + Font.ITALIC, FONT_SIZE));
			g.drawString(chars[n] + "", i * WIDTH / SIZE, HEIGHT / 2);
			// 记录字符
			sb.append(chars[n]);

		}
		// 画干扰线
		for (int i = 0; i < LINES; i++) {
			g.setColor(getRandomColor());
			// 画随机线条
			g.drawLine(r.nextInt(WIDTH), r.nextInt(HEIGHT), r.nextInt(WIDTH), r.nextInt(HEIGHT));
		}

		return new Object[] { sb.toString(), image };
	}

	// 随机颜色
	public static Color getRandomColor() {
		Random r = new Random();
		Color color = new Color(r.nextInt(256), r.nextInt(256), r.nextInt(256));
		return color;
	}
}
