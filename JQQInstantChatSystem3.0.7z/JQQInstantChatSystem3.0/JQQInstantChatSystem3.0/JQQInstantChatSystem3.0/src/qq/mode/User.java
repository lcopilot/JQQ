package qq.mode;

/**
 * @author MuGe
 * @date 创建时间: 2019年6月17日 下午3:31:04
 * @version V1.0
 * @Project JQQInstantChatSystem2.0
 * @Package qq.mode
 */
/*
 * 用户模型
 * 实现Serializable接口 对象序列化
 */
import java.io.Serializable;
import java.util.Vector;

public class User implements Serializable {
	private String name; // 用户名
	private int ID; // ID(QQ)账号
	private String address; // 地址
	private Vector friends; // 好友列表
	private String password;// 密码
	private int status = 0; // 当前状态
//	private String nickName;// 昵称
	private String sex; // 性别
	private String age; // 年龄
	private String shengxiao;// 生肖
	private String constellation;// 星座
	private String bloodType;// 血型
	private String explain;// 个人说明
	private String signature;// 签名
	private String friendId;// 好友ID
	private int QQnum;// 随机数
	private String friendQQname;// 好友昵称
	private int friendQQ;// 好友QQ
	private String mark;// 标志位
	private int friendnumber;// 好友数量
	private String[] friendNameNumber;// 好友姓名的数组
	private int friendNumber1;// 好友编号
	private int groupNumber;// 群数量
	private String groupName;// 群名
	private int groupmembernumber;// 群成员数量
	private int groupId;// 群ID
	private String groupmembername;// 群成员名字
	private int groupmemberId;// 群成员ID

	/**
	 * @return the groupmemberId
	 */
	public int getGroupmemberId() {
		return groupmemberId;
	}

	/**
	 * @param groupmemberId the groupmemberId to set
	 */
	public void setGroupmemberId(int groupmemberId) {
		this.groupmemberId = groupmemberId;
	}

	/**
	 * @return the groupmembername
	 */
	public String getGroupmembername() {
		return groupmembername;
	}

	/**
	 * @param groupmembername the groupmembername to set
	 */
	public void setGroupmembername(String groupmembername) {
		this.groupmembername = groupmembername;
	}

	/**
	 * @return the groupId
	 */
	public int getGroupId() {
		return groupId;
	}

	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	/**
	 * @return the groupmembernumber
	 */
	public int getGroupmembernumber() {
		return groupmembernumber;
	}

	/**
	 * @param groupmembernumber the groupmembernumber to set
	 */
	public void setGroupmembernumber(int groupmembernumber) {
		this.groupmembernumber = groupmembernumber;
	}

	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * @return the groupNumber
	 */
	public int getGroupNumber() {
		return groupNumber;
	}

	/**
	 * @param groupNumber the groupNumber to set
	 */
	public void setGroupNumber(int groupNumber) {
		this.groupNumber = groupNumber;
	}

	/**
	 * @return the friendNumber1
	 */
	public int getFriendNumber1() {
		return friendNumber1;
	}

	/**
	 * @param friendNumber1 the friendNumber1 to set
	 */
	public void setFriendNumber1(int friendNumber1) {
		this.friendNumber1 = friendNumber1;
	}

	/**
	 * @return the friendNameNumber
	 */
	public String[] getFriendNameNumber() {
		return friendNameNumber;
	}

	/**
	 * @param friendNameNumber the friendNameNumber to set
	 */
	public void setFriendNameNumber(String[] friendNameNumber) {
		this.friendNameNumber = friendNameNumber;
	}

	/**
	 * @return the serial
	 */
	public int getSerial() {
		return serial;
	}

	/**
	 * @param serial the serial to set
	 */
	public void setSerial(int serial) {
		this.serial = serial;
	}

	private int serial;// 好友编号

	/**
	 * @return the friendnumber
	 */
	public int getFriendnumber() {
		return friendnumber;
	}

	/**
	 * @param friendnumber the friendnumber to set
	 */
	public void setFriendnumber(int friendnumber) {
		this.friendnumber = friendnumber;
	}

	/**
	 * @return the mark
	 */
	public String getMark() {
		return mark;
	}

	/**
	 * @param mark the mark to set
	 */
	public void setMark(String mark) {
		this.mark = mark;
	}

	/**
	 * @return the qQnum
	 */
	public int getQQnum() {
		return QQnum;
	}

	/**
	 * @param qQnum the qQnum to set
	 */
	public void setQQnum(int qQnum) {
		QQnum = qQnum;
	}

	/**
	 * @return the friendQQname
	 */
	public String getFriendQQname() {
		return friendQQname;
	}

	/**
	 * @param friendQQname the friendQQname to set
	 */
	public void setFriendQQname(String friendQQname) {
		this.friendQQname = friendQQname;
	}

	/**
	 * @return the friendQQ
	 */
	public int getFriendQQ() {
		return friendQQ;
	}

	/**
	 * @param friendQQ the friendQQ to set
	 */
	public void setFriendQQ(int friendQQ) {
		this.friendQQ = friendQQ;
	}

	/**
	 * @return the friendId
	 */
	public String getFriendId() {
		return friendId;
	}

	/**
	 * @param friendId the friendId to set
	 */
	public void setFriendId(String friendId) {
		this.friendId = friendId;
	}

	/**
	 * @return the signature
	 */
	public String getSignature() {
		return signature;
	}

	/**
	 * @param signature the signature to set
	 */
	public void setSignature(String signature) {
		this.signature = signature;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getID() {
		return ID;
	}

	public void setID(int strName) {
		ID = strName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Vector getFriends() {
		return friends;
	}

	public void setFriends(Vector friends) {
		this.friends = friends;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

//	public String getNickName() {
//		return nickName;
//	}
//
//	public void setNickName(String nickName) {
//		this.nickName = nickName;
//	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getShengxiao() {
		return shengxiao;
	}

	public void setShengxiao(String shengxiao) {
		this.shengxiao = shengxiao;
	}

	public String getConstellation() {
		return constellation;
	}

	public void setConstellation(String constellation) {
		this.constellation = constellation;
	}

	public String getBloodType() {
		return bloodType;
	}

	public void setBloodType(String bloodType) {
		this.bloodType = bloodType;
	}

	public String getExplain() {
		return explain;
	}

	public void setExplain(String explain) {
		this.explain = explain;
	}

}
