package qq.mode;

import java.io.Serializable;

/*
 * 消息体模型
 */

public class Message implements Serializable {
	private int sendID;// 发送者编号
	private int recevoirID;// 接收者编号
	private String order;// 聊天协议命令字存储变量
	private String messageContenu;// 消息内容
	private String sendTime;// 发送时间
	private String mesType;//
	private int groupId;// 群Id

	/**
	 * @return the groupId
	 */
	public int getGroupId() {
		return groupId;
	}

	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	/**
	 * @return the sendTime
	 */
	public String getSendTime() {
		return sendTime;
	}

	/**
	 * @param sendTime the sendTime to set
	 */
	public void setSendTime(String sendTime) {
		this.sendTime = sendTime;
	}

	/**
	 * @return the messageContenu
	 */
	public String getMessageContenu() {
		return messageContenu;
	}

	/**
	 * @param messageContenu the messageContenu to set
	 */
	public void setMessageContenu(String messageContenu) {
		this.messageContenu = messageContenu;
	}

	/**
	 * @return the mesType
	 */
	public String getMesType() {
		return mesType;
	}

	/**
	 * @param mesType the mesType to set
	 */
	public void setMesType(String mesType) {
		this.mesType = mesType;
	}

	/**
	 * @return the sendID
	 */
	public int getSendID() {
		return sendID;
	}

	/**
	 * @param ownerId the sendID to set
	 */

	/**
	 * @return the recevoirID
	 */
	public int getRecevoirID() {
		return recevoirID;
	}

	/**
	 * @param sendID the sendID to set
	 */
	public void setSendID(int sendID) {
		this.sendID = sendID;
	}

	/**
	 * @param friendId the recevoirID to set
	 */
	public void setRecevoirID(int friendId) {
		this.recevoirID = friendId;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

}
