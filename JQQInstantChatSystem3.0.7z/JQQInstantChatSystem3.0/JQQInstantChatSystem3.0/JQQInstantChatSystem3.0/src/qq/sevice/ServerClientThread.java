package qq.sevice;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;

import qq.mode.Message;
import util.CloseUtil;
import util.MessageType;

/**
 * @author MuGe
 * @date 创建时间: 2019年6月18日 下午8:38:01
 * @version V1.0
 * @Project JQQInstantChatSystem3.0
 * @Package qq.sevice
 */
/*
 * 功能是服务器和某个线程的通信
 */
public class ServerClientThread extends Thread {
	Socket s;
	ObjectInputStream ois;
	ObjectOutputStream oos;
	Message ms;
	UserManager um = new UserManager();

	public ServerClientThread(Socket s) {
		super();
		// 把服务器与该客户端的链接赋给"s"
		this.s = s;
	}

	public void setS(Socket s) {
		this.s = s;
	}

	// 让该线程去通知其他线程
	public void notifyotHer(String iam) {
		// 得到所有在线的人的线程
		HashMap hm = ManagerClientThread.hm;
		Iterator it = hm.keySet().iterator();

		while (it.hasNext()) {
			ms = new Message();
			ms.setMessageContenu(iam);
			ms.setMesType(MessageType.message_ret_onLineFriend);
			// 取出在线用户的Id号
			String onLineUserId = it.next().toString();
			try {
				oos = new ObjectOutputStream(
						ManagerClientThread.getClientThread(Integer.parseInt(onLineUserId)).s.getOutputStream());
				ms.setRecevoirID(Integer.parseInt(onLineUserId));
				oos.writeObject(ms);
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (IOException e) {
				CloseUtil.closeAll(s, ois, oos);
				e.printStackTrace();
			}
		}
	}

	public void run() {
		// 该线程可以接收客户端的信息
		try {
			while (ms != null) {
				ois = new ObjectInputStream(s.getInputStream());
				ms = (Message) ois.readObject();

				// 对从客户端取得的消息进行类型判断,然后做相应的处理
				if (ms.getMesType().equals(MessageType.Message_group)) {
					System.out.println(ms.getSendTime() + "\n" + ms.getSendID() + "号用户给" + ms.getGroupId() + "号群发送群信息: "
							+ ms.getMessageContenu());
					// 转发
					// 取得在线用户
					String res = ManagerClientThread.getAllOnLineUserId();
					String onLineUser[] = res.split(" ");
					// 读取群成员数量
					int GroupMemberNumber = um.getgroupMemberNumber(ms.getGroupId()).getGroupmembernumber();
					for (int i = 0; i < onLineUser.length; i++) {
						for (int k = 0; k < GroupMemberNumber; k++) {
							// 读取群成员Id
							int GroupMemberId = um.getgroupMemberID(ms.getGroupId(), k).getGroupmemberId();
							// 如果在线用户不是群成员,则不发送
							if (Integer.parseInt(onLineUser[i]) != GroupMemberId) {
								continue;
							}
							// 接收者id和发送者id相同,跳过
							if (Integer.parseInt(onLineUser[i]) == ms.getSendID()) {
								continue;
							}
							// 设置接收者ID
							ms.setRecevoirID(Integer.parseInt(onLineUser[i]));
							// 取得接收者线程
							ServerClientThread sct = ManagerClientThread
									.getClientThread(Integer.parseInt(onLineUser[i]));
							oos = new ObjectOutputStream(sct.s.getOutputStream());
							oos.writeObject(ms);
						}
					}
				}
				if (ms.getMesType().equals(MessageType.message_comm_mes)) {
					System.out.println(ms.getSendTime() + "\n" + ms.getSendID() + "号用户给" + ms.getRecevoirID()
							+ "号用户发送信息: " + ms.getMessageContenu());
					// 转发
					// 取得接收人的接收线程
					ServerClientThread sct = ManagerClientThread.getClientThread(ms.getRecevoirID());
					oos = new ObjectOutputStream(sct.s.getOutputStream());
					oos.writeObject(ms);

				}
				if (ms.getMesType().equals(MessageType.message_get_onLineFriend)) {
					// 把在服务器的好友给该客户端返回
					System.out.println("\n" + ms.getSendID() + "号用户要好友在线情况!");
					String res = ManagerClientThread.getAllOnLineUserId();
					Message ms2 = new Message();
					ms2.setMesType(MessageType.message_ret_onLineFriend);
					ms2.setMessageContenu(res);
					ms2.setRecevoirID(ms.getSendID());
					oos = new ObjectOutputStream(s.getOutputStream());
					oos.writeObject(ms2);
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
