package qq.sevice;

import java.util.HashMap;

public class ManageGroupThread {
	public static HashMap hm = new HashMap<String, ServerClientThread>();

	// 向hm中添加一个客户端通讯线程
	public static void addGroupThread(int i, ServerClientThread sct) {
		hm.put(i, sct);

	}

	// 返回通信线程

	/**
	 * @param uid 登录的QQ号
	 * @return 通信线程
	 */
	public static ServerClientThread getGroupThread(int uid) {
		return (ServerClientThread) hm.get(uid);

	}
}
