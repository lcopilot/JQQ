package qq.sevice;

public class test {
	public static String[] sd;
	public static UserManager um = new UserManager();
	public ClientManager cm = new ClientManager();
	public static int ghgh = 0;

	public static void main(String[] args) {
		um = new UserManager();

		int a = um.getgroupMemberID(4, 0).getGroupmemberId();
		System.out.println(a);

//		System.out
//				.println(um.getQQname(100001).getFriendnumber() + "\n" + um.getfriendname(100001, 1).getFriendQQname());
	}

//	public static void dfshj(int ownerId) {
//		
//
////		for (int i = 1; i < um.getQQname(100001).getFriendnumber(); i++) {
////			sd[i] = um.getfriendname(100001, i).getFriendQQname();
////
////		}
//		// ghgh = sd.length;
//	}

}
