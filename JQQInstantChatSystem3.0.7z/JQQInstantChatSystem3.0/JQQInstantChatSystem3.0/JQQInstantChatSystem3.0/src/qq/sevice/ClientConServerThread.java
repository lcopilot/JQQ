package qq.sevice;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

import qq.mode.Message;
import qq.view.ClientUI;
import qq.view.GroupUI;
import qq.view.MainUI;
import util.MessageType;

/**
 * @author MuGe
 * @date 创建时间: 2019年6月23日 下午2:21:44
 * @version V1.0
 * @Project JQQInstantChatSystem3.0
 * @Package qq.sevice
 */
/*
 * 客户端和服务器通信的线程
 */
public class ClientConServerThread extends Thread {
	Message ms;
	private Socket s;

	/**
	 * @return the s
	 */
	public Socket getS() {
		return s;
	}

	/**
	 * @param s the s to set
	 */
	public void setS(Socket s) {
		this.s = s;
	}

	public ClientConServerThread(Socket s) {
		super();
		this.s = s;
	}

	public void run() {
		while (true) {
			// 不断读取服务端发来的信息
			try {
				ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
				ms = (Message) ois.readObject();
				if (ms.getMesType().equals(MessageType.Message_group)) {
					System.out.println("读取到服务器发来的群消息:" + ms.getSendTime() + "\n" + ms.getSendID() + "号用户给"
							+ ms.getGroupId() + "号群发送群信息: " + ms.getMessageContenu());
					// 把从服务器获得的消息,显示到该显示的群聊天界面
					GroupUI gu = ManageGroupUI.getGroupUI(ms.getRecevoirID() + " " + ms.getGroupId());
					// 显示
					gu.showMessage(ms);
				}
				if (ms.getMesType().equals(MessageType.message_comm_mes)) {
					System.out.println("读取到服务器发来的私聊消息:" + ms.getSendTime() + "\n" + ms.getSendID() + "号用户给"
							+ ms.getRecevoirID() + "号用户发送信息: " + ms.getMessageContenu());
					// 把从服务器获得的消息,显示到该显示的聊天界面
					ClientUI cu = ManageClientUI.getClientUI(ms.getRecevoirID() + " " + ms.getSendID());
					// 显示
					cu.showMessage(ms);
				}
				if (ms.getMesType().equals(MessageType.message_ret_onLineFriend)) {
					String con = ms.getMessageContenu();
					String friends[] = con.split(" ");
					int getrecevoir = ms.getRecevoirID();
					// 修改相应的好友列表
					MainUI mu = ManageFriendList.getFriendList(getrecevoir);
					// 更新在线好友
					if (mu != null) {
						mu.upateFriend(ms);
					}

				}

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	private void getClientUI(String string) {
		// TODO Auto-generated method stub

	}

}
