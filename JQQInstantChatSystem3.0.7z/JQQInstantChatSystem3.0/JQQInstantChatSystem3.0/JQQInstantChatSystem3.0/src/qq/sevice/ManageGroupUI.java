package qq.sevice;

import java.util.HashMap;

import qq.view.GroupUI;

public class ManageGroupUI {
	private static HashMap hm = new HashMap<String, GroupUI>();

	// 加入
	public static void addGroupUI(String LoginIdGroupId, GroupUI cu) {
		hm.put(LoginIdGroupId, cu);
	}

	// 取出
	public static GroupUI getGroupUI(String groupId) {
		return (GroupUI) hm.get(groupId);
	}

}
