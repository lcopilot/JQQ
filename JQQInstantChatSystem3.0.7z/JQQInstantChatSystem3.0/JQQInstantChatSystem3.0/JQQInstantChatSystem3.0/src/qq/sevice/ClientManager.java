package qq.sevice;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import qq.mode.Message;
import qq.mode.User;
import util.CloseUtil;

/**
 * @author MuGe
 * @date 创建时间: 2019年6月17日 下午4:27:17
 * @version V1.0
 * @Project JQQInstantChatSystem2.0
 * @Package qq.sevice
 */
public class ClientManager extends Thread {

	ObjectOutputStream oos;
	ObjectInputStream ois;
	Message ms = new Message();
	Socket s;
	User u;

	/*
	 * 线程启动
	 */

	/**
	 * @param u
	 * @return
	 */
	public int CheckUser(User u) {

		return SendRegisterServer(u);
	}

	public int CheckRegister(User u) {
		return SendRegister(u);
	}

	/*
	 * 向服务器发送请求登录验证
	 */
	public int SendRegisterServer(Object o) {
		int reslut = 0;
		try {
			this.s = new Socket("localhost", 8085);
			// 创建对象输出流
			oos = new ObjectOutputStream(s.getOutputStream());
			oos.writeObject(o);

			// 创建对象输入流
			ois = new ObjectInputStream(s.getInputStream());
			ms = (Message) ois.readObject();

			// 验证用户登录
			if (ms.getMesType().equals("1")) {
				// 创建一个该QQ号和服务端保持通讯的线程
				ClientConServerThread ccst = new ClientConServerThread(s);
				// 启动该通讯线程
				ccst.start();
				ManagerClientConServerThread.addClientConServerThread(((User) o).getID(), ccst);
				reslut = 1;
			}
			if (ms.getMesType().equals("3")) {
				reslut = 3;
			}
			if (ms.getMesType().equals("2")) {
				reslut = 2;
			}
			if (ms.getMesType().equals("4")) {
				reslut = 4;
			}

		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			CloseUtil.closeAll(s, ois, oos);
			e.printStackTrace();
		}

		return reslut;
	}

	/*
	 * 向服务器发送对象
	 * 
	 */
	public int SendRegister(Object o) {
		int reslut = 0;
		try {
			s = new Socket("localhost", 8085);
			// 创建对象输出流
			oos = new ObjectOutputStream(s.getOutputStream());
			oos.writeObject(o);

			// 创建对象输入流
			ois = new ObjectInputStream(s.getInputStream());

			ms = (Message) ois.readObject();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (ms.getMesType().equals("4")) {
			reslut = 4;
		}
		if (ms.getMesType().equals("5")) {
			reslut = 5;
		}
		return reslut;
	}

	public int sendFriend(Object o) {
		int result = 0;
		try {
//			s = new Socket("localhost", 8085);
			// 创建对象输出流
			oos = new ObjectOutputStream(s.getOutputStream());
			oos.writeObject(o);
			// 创建对象输入流
			ois = new ObjectInputStream(s.getInputStream());

			ms = (Message) ois.readObject();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			CloseUtil.closeAll(s, ois, oos);
			e.printStackTrace();
		}
		if (ms.getMesType().equals("6")) {
			result = u.getFriendnumber();
		}

		return result;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}
}
