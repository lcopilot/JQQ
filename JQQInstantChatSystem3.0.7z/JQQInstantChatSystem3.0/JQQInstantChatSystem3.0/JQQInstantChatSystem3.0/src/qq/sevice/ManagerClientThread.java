package qq.sevice;

import java.util.HashMap;
import java.util.Iterator;

/**
 * @author MuGe
 * @date 创建时间: 2019年6月22日 下午7:58:31
 * @version V1.0
 * @Project JQQInstantChatSystem3.0
 * @Package qq.sevice
 */
public class ManagerClientThread {

	public static HashMap hm = new HashMap<String, ServerClientThread>();

	// 向hm中添加一个客户端通讯线程
	public static void addClientThread(int i, ServerClientThread sct) {
		hm.put(i, sct);

	}

	// 返回通信线程

	/**
	 * @param uid 登录的QQ号
	 * @return 通信线程
	 */
	public static ServerClientThread getClientThread(int uid) {
		return (ServerClientThread) hm.get(uid);

	}

	// 返回当前在线的人的情况
	public static String getAllOnLineUserId() {
		// 迭代器
		Iterator it = hm.keySet().iterator();
		String res = "";

		while (it.hasNext()) {
			res += it.next().toString() + " ";
		}
		return res;
	}
}
