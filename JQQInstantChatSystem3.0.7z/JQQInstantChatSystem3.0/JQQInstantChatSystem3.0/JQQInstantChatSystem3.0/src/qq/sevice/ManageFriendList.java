package qq.sevice;

import java.util.HashMap;

import qq.view.MainUI;

/**
 * @author MuGe
 * @date 创建时间: 2019年6月24日 上午10:52:09
 * @version V1.0
 * @Project JQQInstantChatSystem3.0
 * @Package qq.sevice
 */
/*
 * 管理好友,黑名单,
 */
public class ManageFriendList {
	public static HashMap hm = new HashMap<String, MainUI>();

	public static void addFriendList(int qqid, MainUI FriendList) {
		hm.put(qqid, FriendList);
	}

	public static MainUI getFriendList(int qqid) {
		return (MainUI) hm.get(qqid);
	}

}
