package qq.sevice;

import java.util.HashMap;

import qq.view.ClientUI;

/**
 * @author MuGe
 * @date 创建时间: 2019年6月23日 下午3:31:16
 * @version V1.0
 * @Project JQQInstantChatSystem3.0
 * @Package qq.sevice
 */
/*
 * 管理用户聊天界面类
 */

public class ManageClientUI {
	private static HashMap hm = new HashMap<String, ClientUI>();

	// 加入
	public static void addClientUI(String LoginIdFriendId, ClientUI cu) {
		hm.put(LoginIdFriendId, cu);
	}

	// 取出
	public static ClientUI getClientUI(String LoginIdFriendId) {
		return (ClientUI) hm.get(LoginIdFriendId);
	}

}
