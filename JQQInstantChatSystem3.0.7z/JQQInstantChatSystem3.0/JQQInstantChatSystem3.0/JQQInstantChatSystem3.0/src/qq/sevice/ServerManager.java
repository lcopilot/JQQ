package qq.sevice;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import qq.mode.Message;
import qq.mode.User;
import qq.view.ServerUI;
import util.CloseUtil;
import util.MessageType;

/*
 * 监听等待客户端链接
 */

/**
 * @author MuGe
 * @date 创建时间: 2019年6月22日 上午11:51:42
 * @version V1.0
 * @Project JQQInstantChatSystem3.0
 * @Package qq.sevice
 */
public class ServerManager {
	ObjectInputStream ois;
	ObjectOutputStream oos;
	User u = new User();
	Message ms = new Message();
	ServerSocket ss;
	UserManager um = new UserManager();
	private Connection conn = null;
	private PreparedStatement pstat = null;
	private ResultSet rs = null;
	Socket s;
	ServerUI su = new ServerUI();

//	public static void main(String[] args) {
//		new ServerManager();
//	}

	public ServerManager() {
		try {
			// 在3355端口监听
			ss = new ServerSocket(8085);
			System.out.println("Hello World 8085 端口为您服务!");
			// 阻塞 等待客户端链接
			while (true) {
				s = ss.accept();
				// 等待客户端发来的信息
				ois = new ObjectInputStream(s.getInputStream());
				u = (User) ois.readObject();
				oos = new ObjectOutputStream(s.getOutputStream());
				// Mark=1处理登录请求
				if (u.getMark().equals("1")) {
					checkUesr(s);
				} // Mark=2处理注册请求
				if (u.getMark().equals("2")) {
					checkRegister(s);
				}
				if (u.getMark().equals("3")) {

				}

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			// CloseUtil.closeAll(ss, s, ois, oos);
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			// CloseUtil.closeAll(ss, s, ois, oos);
			e.printStackTrace();
		}

	}

	/**
	 * 获得好友数量
	 */

	public void getFriendNumber(Socket s) {

	}

	/**
	 *核对用户登录信息
	  */
	public void checkUesr(Socket s) {
		if (um.getQQname(u.getID()) == null) {
			// message_user表示用户不存在,返回一个用户不存在的信息
			ms.setMesType(MessageType.message_user);
			try {
				oos.writeObject(ms);
				s.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				CloseUtil.closeAll(ss, s, ois, oos);
				e.printStackTrace();
			}
		}
		if (!(um.getQQname(u.getID()).getPassword()).equals(u.getPassword())) {
			// message_login_fail表示密码错误,返回一个密码错误的信息
			ms.setMesType(MessageType.message_login_fail);
			try {
				oos.writeObject(ms);
				// 关闭连接
				s.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//CloseUtil.closeAll(ss, s, ois, oos);
				e.printStackTrace();
			}

		}
		if ((um.getQQname(u.getID()).getPassword()).equals(u.getPassword())) {
			// message_succeed表示验证成功 ,返回一个登录成功的信息
			ms.setMesType(MessageType.message_succeed);
			try {
				oos.writeObject(ms);
				System.out.println("\n" + s.getInetAddress().getHostAddress() + "连接到服务器！\nID: " + u.getID() + "\n昵称: "
						+ um.getQQname(u.getID()).getName());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// 单开一个线程,让该线程与该客户端通信
			ServerClientThread sct = new ServerClientThread(s);
			ManagerClientThread.addClientThread(u.getID(), sct);
			// 启动与该客户通信的线程
			sct.start();

			// 并通知在线用户
			sct.notifyotHer(Integer.toString(u.getID()));
		}
	}

	/**
	*核对注册信息
	 */
	public void checkRegister(Socket s) {
		if ((um.getQQname(u.getID()) == null) && (um.getQQ(u.getName()) == null)) {
			// 表示用户不存在,可以注册
			ms.setMesType("4");
			try {
				oos.writeObject(ms);
				um.addUser(u);
				SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				System.out.println(
						"\n" + u.getID() + "号用户注册成功\n时间: " + sf.format(new Date()).toString() + "\n昵称: " + u.getName());
				// 注册类
				for (int i = 0; i < 2; i++) {
					String a;
					if (i == 0) {
						a = "故事没我";
					} else {
						a = "南汐";
					}
					um.addFriendDefault(u.getID(), i + 1, a, i);

				}
				um.addGroup(u.getID());
				um.addGroup_m_list(u.getID(), u.getName());
				s.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				CloseUtil.closeAll(ss, s, ois, oos);
				e.printStackTrace();
			}
		} else if (um.getQQ(u.getName()) != null) {
			System.out.println("\n" + u.getName() + "-用户名已存在,不允许注册");
			// 表示用户存在,不可以注册
			ms.setMesType("5");
			try {
				oos.writeObject(ms);
				s.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				// CloseUtil.closeAll(ss, s, ois, oos);
				e.printStackTrace();
			}
		}
	}

}
