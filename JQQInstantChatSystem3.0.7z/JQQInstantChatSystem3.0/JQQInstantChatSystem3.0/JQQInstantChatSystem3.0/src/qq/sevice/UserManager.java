package qq.sevice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import qq.mode.User;

public class UserManager {
	// 数据库驱动
	public static final String DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	// 数据库连接
	public static final String URL = "jdbc:sqlserver://localhost:1433;Database=JQQ-1";
	// 数据库登入用户名
	public static final String DBNAME = "sa";
	// 数据库登入密码
	public static final String DBPASS = "3476595lxl";

	private Connection conn = null;
	private PreparedStatement pstat = null;
	private ResultSet rs = null;

	// 创建数据库连接
	public Connection getConn() throws ClassCastException, SQLException {
		// 加载驱动
		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 得到连接对象
		conn = DriverManager.getConnection(URL, DBNAME, DBPASS);
		return conn;
	}

	// 释放资源
	public void closeAll() {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (rs != null) {
			try {
				pstat.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (rs != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// 查询
	public User getQQname(int QQ) {
		User u = null;
		try {
			conn = getConn();
			String sql = "select * from Userlnfo where QQ=?";
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, QQ);
			rs = pstat.executeQuery();
			// 结果结果集
			while (rs.next()) {
				u = new User();
				u.setName(rs.getString("nickname"));
				u.setID(rs.getInt("QQ"));
				u.setSignature(rs.getString("sign"));
				u.setPassword(rs.getString("pwd"));
				u.setSex(rs.getString("sex"));
				u.setAge(rs.getString("birthday"));
				u.setAddress(rs.getString("address"));
				u.setConstellation(rs.getString("constellation"));
				u.setFriendnumber(rs.getInt("friendQuantity"));
//				u.setSQLnumber(rs.getRow());
			}

		} catch (ClassCastException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return u;
	}

	// 实现插入用户数据方法
	public int addUser(User u) throws Exception {
		conn = this.getConn();
		String sql = "insert into Userlnfo(pwd,sign,nickname,sex,birthday,constellation,bloodType,address,Zodiac,qq)values(?,?,?,?,?,?,?,?,?,?)";
		pstat = conn.prepareStatement(sql);
		pstat.setString(1, u.getPassword());// 密码
		pstat.setString(2, u.getSignature());// 签名
		pstat.setString(3, u.getName());// 昵称
		pstat.setString(4, u.getSex());// 性别
		pstat.setString(5, u.getAge());// 日期
		pstat.setString(6, u.getConstellation());// 星座
		pstat.setString(7, u.getBloodType());// 血型
		pstat.setString(8, u.getAddress());// 地址;
		pstat.setString(9, u.getShengxiao());// 生肖
		pstat.setInt(10, u.getID());// 随机数

		int result = pstat.executeUpdate();
		return result;

	}

	// 获得好友人数
	public User getfriend(int QQ) {
		User u = null;
		try {
			conn = this.getConn();
			String sql = "SELECT FriendQQ,friendname from Friend where QQ=?";
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, QQ);
			rs = pstat.executeQuery();
			while (rs.next()) {
				u = new User();
				u.setFriendQQ(rs.getInt("friendQQ"));
				u.setFriendQQname(rs.getString("friendname"));
			}
		} catch (ClassCastException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	// 获得好友昵称
	public User getfriendname(int QQ, int serial) {
		User u = null;
		try {
			conn = this.getConn();
			String sql = "select friendname from friend where qq=? AND serial=?";
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, QQ);
			pstat.setInt(2, serial);
			rs = pstat.executeQuery();
			while (rs.next()) {
				u = new User();
				u.setFriendQQname(rs.getString("friendname"));
			}
		} catch (ClassCastException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	// 获得好友QQ
	public User getfriendQQ1(String name) {
		User u = null;
		try {
			conn = this.getConn();
			String sql = "select friendQQ from friend where friendname=?  ";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, name);
			rs = pstat.executeQuery();

			while (rs.next()) {
				u = new User();
				u.setFriendQQ(rs.getInt("friendQQ"));
			}

		} catch (ClassCastException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	// 查找用户
	public User getQQ(String name) {
		User u = null;
		try {
			conn = getConn();
			String sql = "select * from Userlnfo where nickname=?";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, name);
			rs = pstat.executeQuery();
			// 结果结果集
			while (rs.next()) {
				u = new User();
				u.setID(rs.getInt("QQ"));
			}

		} catch (ClassCastException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return u;
	}

	// 获得好友编号
	public User getfriendNumder(int QQ, int friendID) {
		User u = null;
		try {
			conn = this.getConn();
			String sql = "select serial from friend where qq=? AND friendQQ=?";
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, QQ);
			pstat.setInt(2, friendID);
			rs = pstat.executeQuery();
			while (rs.next()) {
				u = new User();
				u.setFriendNumber1(rs.getInt("serial"));
			}
		} catch (ClassCastException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	// 获得群名字
	public User getgroupNumber(int QQ, int number) {
		User u = null;
		try {
			conn = this.getConn();
			String sql = "select grouo_name from group_list where QQ=? AND grouo_number1=?";
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, QQ);
			pstat.setInt(2, number);
			rs = pstat.executeQuery();
			while (rs.next()) {
				u = new User();
				u.setGroupName(rs.getString("grouo_name"));
			}
		} catch (ClassCastException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	// 获取群成员数量
	public User getgroupMemberNumber(int g_number) {
		User u = null;
		try {
			conn = this.getConn();
			String sql = "select g_m_name from group_m_list where g_number=?";
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, g_number);
			rs = pstat.executeQuery();
			while (rs.next()) {
				u = new User();
				u.setGroupmembernumber(rs.getRow());
			}
		} catch (ClassCastException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	// 获取群ID
	public User getgroupID(String g_name) {
		User u = null;
		try {
			conn = this.getConn();
			String sql = "select group_number from group_list where grouo_name=?";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, g_name);
			rs = pstat.executeQuery();
			while (rs.next()) {
				u = new User();
				u.setGroupId(rs.getInt("group_number"));
			}
		} catch (ClassCastException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	// 获得群数量
	public User getgroupNumber(int QQ) {
		User u = null;
		try {
			conn = this.getConn();
			String sql = "select grouo_name from group_list where QQ=? ";
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, QQ);
			rs = pstat.executeQuery();
			while (rs.next()) {
				u = new User();
				u.setGroupNumber(rs.getRow());
			}
		} catch (ClassCastException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	// 获得群成员名字
	public User getgroupMemberName(int groupId, int i) {
		User u = null;
		try {
			conn = this.getConn();
			String sql = "select g_m_name from group_m_list where g_number=? AND g_m_number=? ";
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, groupId);
			pstat.setInt(2, i);
			rs = pstat.executeQuery();
			while (rs.next()) {
				u = new User();
				u.setGroupmembername(rs.getString("g_m_name"));
			}
		} catch (ClassCastException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	// 群成员ID
	public User getgroupMemberID(int g_number, int MemberID) {
		User u = null;
		try {
			conn = this.getConn();
			String sql = "select g_m_id from group_m_list where g_number=? AND g_m_number=?";
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, g_number);
			pstat.setInt(2, MemberID);
			rs = pstat.executeQuery();
			while (rs.next()) {
				u = new User();
				u.setGroupmemberId(rs.getInt("g_m_id"));
			}
		} catch (ClassCastException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	// 好友资料

	public User getQQname1(int QQ) {
		User u = null;
		try {
			conn = getConn();
			String sql = "select * from Userlnfo where QQ=?";
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, QQ);
			rs = pstat.executeQuery();
			// 结果结果集
			while (rs.next()) {
				u = new User();
				u.setName(rs.getString("nickname"));
				u.setID(rs.getInt("QQ"));
				u.setSignature(rs.getString("sign"));
				u.setPassword(rs.getString("pwd"));
				u.setSex(rs.getString("sex"));
				u.setAge(rs.getString("birthday"));
				u.setAddress(rs.getString("address"));
				u.setConstellation(rs.getString("constellation"));
				u.setFriendnumber(rs.getInt("friendQuantity"));
				u.setShengxiao(rs.getString("Zodiac"));
				u.setBloodType(rs.getString("bloodType"));
				u.setExplain((rs.getString("introduce")));

			}

		} catch (ClassCastException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return u;
	}

	// 修改好友资料
	public int setmessage(User u, int qQ) {
		// TODO Auto-generated method stub
		int result = 0;
		try {
			conn = this.getConn();
			String sql = "UPDATE Userlnfo SET nickname =?,sign=?,sex=?,birthday=?,constellation=?,bloodType=?,address=?,introduce=?,Zodiac=? WHERE qq=?";
			pstat = conn.prepareStatement(sql);

			pstat.setString(1, u.getName());// 昵称
			pstat.setString(2, u.getSignature());// 签名
			pstat.setString(3, u.getSex());// 性别
			pstat.setString(4, u.getAge());// 日期
			pstat.setString(5, u.getConstellation());// 星座
			pstat.setString(6, u.getBloodType());// 血型
			pstat.setString(7, u.getAddress());// 地址;
			pstat.setString(8, u.getExplain());// 个人说明
			pstat.setString(9, u.getShengxiao());// 生肖
			pstat.setInt(10, qQ);// QQ
			result = pstat.executeUpdate();
			return result;
		} catch (ClassCastException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		}
	}

	// 查询好友列表

	public User getFriendQQList(int QQ, int freindQQ) {

		User u = null;
		try {
			conn = this.getConn();
			String sql = "select friendQQ  from friend  where QQ=? AND friendQQ=?";
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, QQ);
			pstat.setInt(2, freindQQ);
			rs = pstat.executeQuery();
			while (rs.next()) {
				u.setFriendQQ(rs.getInt("friendQQ"));

			}
		} catch (ClassCastException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;

	}

	// 添加好友
	public User addFriend(int QQ, int freindQQ, String friendname) {
		User u = null;
		try {
			conn = this.getConn();
			String sql = "insert into friend(QQ,friendQQ,friendname)values(?,?,?)";
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, QQ);
			pstat.setInt(2, freindQQ);
			pstat.setString(3, friendname);
			rs = pstat.executeQuery();
			while (rs.next()) {
				u = new User();
				u.setFriendNumber1(rs.getInt("serial"));
			}
		} catch (ClassCastException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	// 插入默认好友
	public int addFriendDefault(int QQ, int friendQQ, String friendName, int serial) {
		int result = 0;
		try {

			conn = this.getConn();
			String sql = "insert into friend(QQ,friendQQ,friendname,serial)values(?,?,?,?)";
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, QQ);
			pstat.setInt(2, friendQQ);
			pstat.setString(3, friendName);
			pstat.setInt(4, serial);
			rs = pstat.executeQuery();
			result = pstat.executeUpdate();

			return result;
		} catch (ClassCastException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			return -1;
		}
	}

	// 插入默认群列表
	public int addGroup(int QQ) {
		int result = 0;
		try {
			conn = this.getConn();
			String sql = "insert into group_list(QQ)values(?)";
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, QQ);
			rs = pstat.executeQuery();
			return result;
		} catch (ClassCastException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			return -1;
		}
	}

	// 插入默认群成员
	public int addGroup_m_list(int QQ, String name) {
		int result = 0;
		try {
			conn = this.getConn();
			String sql = "insert into group_m_list(g_m_id,g_m_name)values(?,?)";
			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, QQ);
			pstat.setString(2, name);
			rs = pstat.executeQuery();
			return result;
		} catch (ClassCastException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			return -1;
		}
	}

}
