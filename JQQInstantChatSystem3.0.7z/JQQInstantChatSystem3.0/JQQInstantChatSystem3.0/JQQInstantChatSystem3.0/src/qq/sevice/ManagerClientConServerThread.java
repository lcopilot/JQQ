package qq.sevice;

import java.util.HashMap;

/**
 * @author MuGe
 * @date 创建时间: 2019年6月23日 下午2:37:07
 * @version V1.0
 * @Project JQQInstantChatSystem3.0
 * @Package qq.sevice
 */
/*
 * 管理一个客户端和服务器保持通讯的线程
 */
public class ManagerClientConServerThread {
	public static HashMap hm = new HashMap<String, ClientConServerThread>();

	// 把创建好的ClientConServerThread放到hm
	public static void addClientConServerThread(int qqId, ClientConServerThread ccst) {
		hm.put(qqId, ccst);
	}

	// 可以通过qqid取得该线程
	public static ClientConServerThread getClientConServerThread(int qqId) {
		return (ClientConServerThread) hm.get(qqId);
	}
}
