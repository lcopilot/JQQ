package qq.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.border.EmptyBorder;

import qq.mode.Message;
import qq.mode.User;
import qq.sevice.ClientManager;
import qq.sevice.ManageClientUI;
import qq.sevice.ManageGroupUI;
import qq.sevice.ServerManager;
import qq.sevice.UserManager;

/**
 * @author MuGe
 * @date 创建时间: 2019年6月22日 上午11:52:16
 * @version V1.0
 * @Project JQQInstantChatSystem3.0
 * @Package qq.view
 */
public class MainUI extends JFrame implements MouseListener {

	private JPanel contentPane;
	JPanel friendJPanel;
	JScrollPane FriendListJSP;
	JLabel[] photoJLabel;
	ClientUI cu;
	Message ms;
	User u = new User();
	String friendName;
	int ownerId;// 自己的ID
	int friendid;// 好友ID
	UserManager um = new UserManager();
	ServerManager sm;
	ClientManager cm;
	JLabel[] groupJPanel;
	JScrollPane GroupChatJSP;
	GroupUI gu;
	int groupId;// 群ID
	private static boolean flag = false;// 用来判断是否已经执行双击事件
	private static int clickNum = 0;// 用来判断是否该执行双击事件
	JPopupMenu popu;
	JMenuItem selete;
	JMenuItem look;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					MainUI frame = new MainUI(100001);
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
	}

	/**
	 * Create the frame.
	 */
	public MainUI(int ownerId) {
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainUI.class.getResource("/image/\u5934\u50CF.jpg")));
		this.ownerId = ownerId;
		setTitle("\u4E3B\u7A97\u4F53");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(1350, 100, 369, 773);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 345, 120);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel UserAvatarJLabel = new JLabel("");
		UserAvatarJLabel.addMouseListener(new MouseAdapter() {
			@Override
			// 弹出个人资料
			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == e.BUTTON1) {
					popupMessage();
				}
			}
		});
		UserAvatarJLabel.setIcon(new ImageIcon(MainUI.class.getResource("/image/\u4E2A\u4EBA\u5934\u50CF.png")));
		UserAvatarJLabel.setBounds(32, 13, 65, 65);
		panel.add(UserAvatarJLabel);

		JLabel textNameJLabel = new JLabel("");
		textNameJLabel.setBounds(127, 13, 150, 39);
		textNameJLabel.setText(um.getQQname(ownerId).getName());
		panel.add(textNameJLabel);

		JLabel lblNewLabel = new JLabel(um.getQQname1(ownerId).getSignature());
		lblNewLabel.setBounds(127, 50, 129, 28);
		panel.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(MainUI.class.getResource("/image/\u5934\u50CF\u80CC\u666F3.png")));
		lblNewLabel_1.setBounds(0, 0, 345, 120);
		panel.add(lblNewLabel_1);

		JTabbedPane TypeJTabbedPane = new JTabbedPane(JTabbedPane.TOP);
		TypeJTabbedPane.setFont(new Font("宋体", Font.PLAIN, 18));
		TypeJTabbedPane.setBounds(0, 122, 352, 551);
		contentPane.add(TypeJTabbedPane);

		FriendListJSP = new JScrollPane();
		TypeJTabbedPane.addTab("    \u597D\u53CB\u5217\u8868    ", null, FriendListJSP, null);

		friendJPanel = new JPanel();

		FriendListJSP.setViewportView(friendJPanel);
		friendJPanel.setLayout(new GridLayout(35, 1, 4, 4));
		int friendNumber = um.getQQname(ownerId).getFriendnumber();
		if (friendNumber != 0) {
			photoJLabel = new JLabel[friendNumber];
			for (int i = 0; i < photoJLabel.length; i++) {
				photoJLabel[i] = new JLabel(um.getfriendname(ownerId, i).getFriendQQname() + "",
						new ImageIcon(MainUI.class.getResource("/image/\u5934\u50CF.jpg")), JLabel.LEFT);
				photoJLabel[i].setEnabled(false);
				photoJLabel[i].addMouseListener(this);
				// photoJLabel[i].addMouseListener(new mouseLis());
				friendJPanel.add(photoJLabel[i]);
			}
		}

		GroupChatJSP = new JScrollPane();
		TypeJTabbedPane.addTab("      \u7FA4\u804A      ", null, GroupChatJSP, null);

		JPanel GroupJPanel = new JPanel();
		GroupChatJSP.setViewportView(GroupJPanel);
		GroupJPanel.setLayout(new GridLayout(35, 1, 4, 4));

		JButton btnNewButton = new JButton("\u6DFB\u52A0\u597D\u53CB");
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(new Color(102, 204, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddFriendUI afu = new AddFriendUI();
				afu.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("微软雅黑", Font.PLAIN, 16));
		btnNewButton.setBounds(28, 683, 120, 35);
		contentPane.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\u6DFB\u52A0\u7FA4");
		btnNewButton_1.setBackground(new Color(102, 204, 255));
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setFont(new Font("微软雅黑", Font.PLAIN, 16));
		btnNewButton_1.setBounds(191, 683, 120, 35);
		contentPane.add(btnNewButton_1);

		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(MainUI.class.getResource("/image/\u5934\u50CF\u80CC\u666F3.png")));
		lblNewLabel_2.setBounds(0, 672, 345, 61);
		contentPane.add(lblNewLabel_2);

		int groipNumber = um.getgroupNumber(ownerId).getGroupNumber();
		if (groipNumber != 0) {
			groupJPanel = new JLabel[groipNumber];
			for (int i = 0; i < groupJPanel.length; i++) {
				groupJPanel[i] = new JLabel(um.getgroupNumber(ownerId, i).getGroupName() + "",
						new ImageIcon(MainUI.class.getResource("/image/\u5934\u50CF.jpg")), JLabel.LEFT);
				groupJPanel[i].addMouseListener(this);
				GroupJPanel.add(groupJPanel[i]);

			}

		}

	}

	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		final MouseEvent me = e;// 事件源
		if (e.getButton() == MouseEvent.BUTTON1) {
			this.flag = false;// 每次点击鼠标初始化双击事件执行标志为false

			if (this.clickNum == 1) {// 当clickNum==1时执行双击事件
				this.mouseDoubleClicked(me);// 执行双击事件
				this.clickNum = 0;// 初始化双击事件执行标志为0
				this.flag = true;// 双击事件已执行,事件标志为true
				return;
			}

			// 定义定时器
			java.util.Timer timer = new java.util.Timer();

			// 定时器开始执行,延时0.2秒后确定是否执行单击事件
			timer.schedule(new java.util.TimerTask() {
				private int n = 0;// 记录定时器执行次数

				public void run() {
					if (flag) {// 如果双击事件已经执行,那么直接取消单击执行
						n = 0;
						clickNum = 0;
						this.cancel();
						return;
					}
					// 定时器等待0.4秒后,双击事件仍未发生,执行单击事件
					if (n == 1) {
						mouseSingleClicked(me);// 执行单击事件
						flag = true;
						clickNum = 0;
						n = 0;
						this.cancel();
						return;
					}
					clickNum++;
					n++;
				}
			}, new java.util.Date(), 400);
		}
	}

	/**
	 * 鼠标单击事件
	 * 
	 * @param e 事件源参数
	 */
	public void mouseSingleClicked(MouseEvent e) {
		// 获得群名
		String groupName = ((JLabel) e.getSource()).getText();
		groupId = um.getgroupID(groupName).getGroupId();
		gu = new GroupUI(groupName, groupId, ownerId);
		// 把群聊加入到管理类中
		ManageGroupUI.addGroupUI(this.ownerId + " " + groupId, gu);
		gu.setVisible(true);
	}

	/**
	 * 鼠标双击事件
	 * 
	 * @param e 事件源参数
	 */
	public void mouseDoubleClicked(MouseEvent e) {
		// 得到好友昵称
		friendName = ((JLabel) e.getSource()).getText();
		friendid = um.getfriendQQ1(friendName).getFriendQQ();
		cu = new ClientUI(this.ownerId, friendName, friendid);
		// 把聊天界面加入到管理类中
		ManageClientUI.addClientUI(this.ownerId + " " + friendid, cu);
		cu.setVisible(true);
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		JLabel js = (JLabel) e.getSource();
		js.setForeground(Color.RED);
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		JLabel js = (JLabel) e.getSource();
		js.setForeground(Color.BLACK);
	}

	public int sendFriend() {
		cm = new ClientManager();
		int result = 0;
		u = new User();
		u.setID(ownerId);
		result = cm.sendFriend(u);
		return result;
	}

	// 更新在线好友的情况
	public void upateFriend(Message ms) {
		String onLineFriend[] = ms.getMessageContenu().split(" ");
		for (int i = 0; i < onLineFriend.length; i++) {
			int onLine = Integer.parseInt(onLineFriend[i]);
			// int Friendnumber = um.getfriendNumder(ms.getRecevoirID(),
			// onLine).getFriendNumber1();
			photoJLabel[onLine - 1].setEnabled(true);
			;
		}
	}

	// 弹出自己资料
	public void popupMessage() {
		UserDataUI udu = new UserDataUI(ownerId);
		udu.setVisible(true);
	}
}
