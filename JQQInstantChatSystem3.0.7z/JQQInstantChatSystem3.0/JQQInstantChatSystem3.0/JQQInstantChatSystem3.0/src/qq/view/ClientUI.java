package qq.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import qq.mode.Message;
import qq.mode.User;
import qq.sevice.ManagerClientConServerThread;
import util.CloseUtil;

public class ClientUI extends JFrame {
	private static final long serialVersionUID = 1450246294863000984L;
	private JPanel contentPane;
	private Color THEME_COLOR = new Color(140, 99, 79);
	private Color BACKGROUND_COLOR = new Color(248, 248, 248);
	private ImageIcon[] CHATBAR_ICON = new ImageIcon[7];
	private JTextArea chatShowtArea;
	private JTextArea chatInputtArea;

	private Socket s;
	ObjectInputStream ois;
	ObjectOutputStream oos;
	int ownerId;
	String friendName;
	int friendId;
	Message ms = new Message();
	User u;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
//		ClientUI cs = new ClientUI();
//		cs.setVisible(true);
//
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					ClientUI frame = new ClientUI();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
	}

	/**
	 * Create the frame.
	 */
	public ClientUI(int ownerId, String friendName, int friendId) {
		this.ownerId = ownerId;
		this.friendId = friendId;
		this.friendName = friendName;
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(ClientUI.class.getResource("/image/\u4E2A\u4EBA\u5934\u50CF.png")));
		setUndecorated(true);
		new MobileNoBorderFrameTool(this);
		setTitle("\u5BA2\u6237\u7AEF");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 771, 661);
		this.setLocationRelativeTo(null);// 设置在屏幕中央显示
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel vertexBar = new JPanel();
		vertexBar.setBackground(Color.WHITE);
		vertexBar.setForeground(Color.BLACK);
		vertexBar.setBounds(0, 0, 771, 53);
		contentPane.add(vertexBar);
		vertexBar.setLayout(null);

		JButton MinButton = new JButton("");
		MinButton.setBounds(699, 0, 30, 30);
		vertexBar.add(MinButton);
		MinButton.setIcon(new ImageIcon(ClientUI.class.getResource("/image/\u6700\u5C0F\u5316 1.png")));
		MinButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setExtendedState(ICONIFIED);
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				MinButton.setIcon(new ImageIcon(ClientUI.class.getResource("/image/\u6700\u5C0F\u5316.png")));
			}

			@Override
			public void mouseExited(MouseEvent e) {
				MinButton.setIcon(new ImageIcon(ClientUI.class.getResource("/image/\u6700\u5C0F\u5316.png")));
			}
		});

		JButton CloseButton = new JButton("");
		CloseButton.setBounds(740, 0, 30, 30);
		vertexBar.add(CloseButton);
		CloseButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				CloseButton.setBackground(Color.RED);
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}
		});
		CloseButton.setIcon(new ImageIcon(ClientUI.class.getResource("/image/\u5173\u95ED1.png")));

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FriendDataUI fdu = new FriendDataUI(friendId);
				fdu.setVisible(true);
			}
		});
		lblNewLabel.setBounds(323, 0, 136, 53);
		vertexBar.add(lblNewLabel);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setFont(new Font("微软雅黑", Font.BOLD, 25));
		lblNewLabel.setText(friendName);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);

		JLabel backdropJLabel = new JLabel("");
		backdropJLabel.setIcon(new ImageIcon(ClientUI.class.getResource("/image/\u4E2A\u4EBA\u98762.png")));
		backdropJLabel.setBounds(0, 0, 771, 53);
		vertexBar.add(backdropJLabel);

		JScrollPane chatInputScrollPane = new JScrollPane();
		chatInputScrollPane.setBounds(0, 400, 771, 197);
		contentPane.add(chatInputScrollPane);

		chatInputtArea = new JTextArea();
		chatInputtArea.setForeground(Color.BLACK);
		chatInputtArea.setFont(new Font("微软雅黑", Font.PLAIN, 20));
		chatInputScrollPane.setViewportView(chatInputtArea);

		JPanel chatInputBar = new JPanel();
		chatInputBar.setBounds(0, 356, 769, 42);
		contentPane.add(chatInputBar);
		chatInputBar.setLayout(null);

		JLabel priture1 = new JLabel("");
		priture1.setIcon(new ImageIcon(ClientUI.class.getResource("/image/\u7B11\u8138\u5C0F\u56FE\u6807.png")));
		priture1.setBounds(14, 7, 30, 30);
		chatInputBar.add(priture1);

		JLabel priture2 = new JLabel("");
		priture2.setIcon(new ImageIcon(ClientUI.class.getResource("/image/\u8BED\u97F3\u5C0F\u56FE\u6807.png")));
		priture2.setBounds(71, 7, 30, 30);
		chatInputBar.add(priture2);

		JLabel priture3 = new JLabel("");
		priture3.setIcon(new ImageIcon(ClientUI.class.getResource("/image/\u56FE\u7247\u5C0F\u56FE\u6807.png")));
		priture3.setBounds(128, 7, 30, 30);
		chatInputBar.add(priture3);

		JLabel priture4 = new JLabel("");
		priture4.setIcon(new ImageIcon(ClientUI.class.getResource("/image/\u5F55\u50CF\u5C0F\u56FE\u6807.png")));
		priture4.setBounds(192, 7, 30, 30);
		chatInputBar.add(priture4);

		JLabel priture5 = new JLabel("");
		priture5.setIcon(new ImageIcon(ClientUI.class.getResource("/image/\u622A\u56FE\u5C0F\u56FE\u6807.png")));
		priture5.setBounds(256, 7, 30, 30);
		chatInputBar.add(priture5);

		JLabel priture6 = new JLabel("");
		priture6.setIcon(new ImageIcon(ClientUI.class.getResource("/image/\u7535\u8BDD\u5C0F\u56FE\u6807.png")));
		priture6.setBounds(706, 7, 30, 30);
		chatInputBar.add(priture6);

		JLabel priture7 = new JLabel("");
		priture7.setIcon(new ImageIcon(ClientUI.class.getResource("/image/\u793C\u7269i\u5C0F\u56FE\u6807.png")));
		priture7.setBounds(640, 7, 30, 30);
		chatInputBar.add(priture7);

		JScrollPane chatShowScrollPane = new JScrollPane();
		chatShowScrollPane.setBounds(0, 53, 771, 303);
		contentPane.add(chatShowScrollPane);

		chatShowtArea = new JTextArea();
		chatShowtArea.setEditable(false);
		chatShowtArea.setForeground(Color.BLACK);
		chatShowtArea.setFont(new Font("微软雅黑", Font.PLAIN, 20));
		chatShowScrollPane.setViewportView(chatShowtArea);

		JButton sendButton = new JButton("\u53D1  \u9001");
		sendButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendMessage();
			}
		});
		sendButton.setForeground(Color.WHITE);
		sendButton.setBackground(Color.BLUE);
		sendButton.setBorder(null);
		sendButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				sendButton.setBackground(Color.gray);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				sendButton.setBackground(Color.BLUE);
			}
		});
		sendButton.setBounds(630, 610, 113, 40);
		contentPane.add(sendButton);
		sendButton.setFont(new Font("微软雅黑", Font.BOLD, 20));

		JButton closeButton = new JButton("\u5173  \u95ED");
		closeButton.setForeground(Color.WHITE);
		closeButton.setBackground(Color.BLUE);
		closeButton.setBorder(null);
		closeButton.setBounds(374, 610, 113, 37);
		contentPane.add(closeButton);
		closeButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				closeButton.setBackground(Color.gray);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				closeButton.setBackground(Color.BLUE);
			}
		});
		closeButton.setFont(new Font("微软雅黑", Font.BOLD, 20));

		JPanel panel = new JPanel();
		panel.setBounds(0, 601, 771, 60);
		contentPane.add(panel);
	}

	/*
	 * 发送消息的方法
	 */
	public void sendMessage() {
		// 如果用户点击了,发送按钮
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		ms = new Message();
		ms.setMesType(util.MessageType.message_comm_mes);
		ms.setSendID(this.ownerId);
		ms.setRecevoirID(this.friendId);
		ms.setMessageContenu(chatInputtArea.getText());
		ms.setSendTime(sf.format(new Date()).toString());
		try {
			// 发送给服务器
			oos = new ObjectOutputStream(
					ManagerClientConServerThread.getClientConServerThread(ownerId).getS().getOutputStream());
			oos.writeObject(ms);
			this.chatShowtArea.append(sf.format(new Date()).toString() + "\n我: " + chatInputtArea.getText() + "\n");
			this.chatInputtArea.setText("");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			CloseUtil.closeAll(s, ois, oos);
			e.printStackTrace();
		}
	}

	// 显示消息
	public void showMessage(Message ms) {
		String info = ms.getSendTime() + "\n" + this.friendName + ": " + ms.getSendID() + ms.getMessageContenu() + "\n";
		this.chatShowtArea.append(info);
	}
}