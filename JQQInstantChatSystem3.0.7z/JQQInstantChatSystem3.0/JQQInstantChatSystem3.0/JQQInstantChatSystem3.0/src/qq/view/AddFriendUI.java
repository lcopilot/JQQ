package qq.view;

import java.awt.Button;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import qq.mode.User;
import qq.sevice.UserManager;

public class AddFriendUI extends JFrame {
	String c = null;
	String a = null;
	private JPanel contentPane;
	private JTextField QQnumtextField;
	Panel panel_1;
	Panel panel_2;
	Label label_3;
	Label label_4;
	UserManager um = new UserManager();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddFriendUI frame = new AddFriendUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddFriendUI() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(AddFriendUI.class.getResource("/image/\u5934\u50CF.jpg")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 526, 321);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		Panel panel = new Panel();
		panel.setBounds(5, 5, 512, 87);
		contentPane.add(panel);
		panel.setLayout(null);

		QQnumtextField = new JTextField();
		QQnumtextField.setBounds(116, 18, 268, 33);
		panel.add(QQnumtextField);
		QQnumtextField.setColumns(10);

		Button button = new Button("\u67E5\u8BE2");
		button.setActionCommand("");
		button.setForeground(new Color(0, 0, 0));
		button.setFont(new Font("微软雅黑", Font.PLAIN, 18));
		button.setBackground(new Color(153, 204, 255));
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == e.BUTTON1) {
					a = QQnumtextField.getText().trim();
					int b = Integer.parseInt(a);

					User z = um.getQQname1(b);
					if (z != null) {
						c = um.getQQname1(b).getName();
						if (a != null) {
							ff(a, c);
							panel_1.setVisible(true);
						}
						System.out.println(a);
						System.out.println(c);
					} else {
						Object message = "该用户不存在";
						JOptionPane.showMessageDialog(getComponent(0), message);
					}

				}
			}
		});
		button.setBounds(410, 16, 76, 33);
		panel.add(button);

		Label label = new Label("\u597D\u53CB\u8D26\u53F7\uFF1A");
		label.setForeground(new Color(0, 0, 0));
		label.setFont(new Font("微软雅黑", Font.PLAIN, 18));
		label.setBackground(new Color(153, 204, 255));
		label.setBounds(10, 18, 86, 35);
		panel.add(label);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(AddFriendUI.class.getResource("/image/\u4FEE\u65394.png")));
		lblNewLabel_1.setBounds(-3, -2, 515, 88);
		panel.add(lblNewLabel_1);

		panel_1 = new Panel();
		panel_1.setBounds(5, 90, 507, 130);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		panel_2 = new Panel();
		panel_2.setBounds(10, 10, 487, 110);
		panel_1.add(panel_2);
		panel_2.setLayout(null);
		panel_1.setVisible(false);
		Label label_1 = new Label("\u8D26\u53F7\uFF1A");
		label_1.setForeground(new Color(0, 0, 0));
		label_1.setFont(new Font("微软雅黑", Font.PLAIN, 18));
		label_1.setBackground(new Color(153, 204, 255));
		label_1.setBounds(10, 10, 69, 36);
		panel_2.add(label_1);

		Label label_2 = new Label("\u7528\u6237\u540D\uFF1A");
		label_2.setForeground(new Color(0, 0, 0));
		label_2.setFont(new Font("微软雅黑", Font.PLAIN, 18));
		label_2.setBackground(new Color(153, 204, 255));
		label_2.setBounds(10, 61, 69, 39);
		panel_2.add(label_2);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(AddFriendUI.class.getResource("/image/\u52A0\u597D\u53CB\u56FE\u6807.png")));
		lblNewLabel.setFont(new Font("微软雅黑", Font.PLAIN, 15));
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override

			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == e.BUTTON1) {

					String qq = label_3.getText().trim();
					int c = Integer.parseInt(qq);
					String name = label_4.getText().trim();
					System.out.println(qq + name);
					User a = um.getFriendQQList(12345, c);
					if (a == null) {
						um.addFriend(12345, c, name);// 调用添加好友方法
						JOptionPane.showInputDialog(this, "添加成功");
						System.out.println(um.addFriend(12345, c, name).getFriendQQ());
					} else {
						JOptionPane.showInputDialog(this, "该用户已经是你的好友");
					}
				}

			}
		});
		lblNewLabel.setBounds(394, 41, 26, 26);
		panel_2.add(lblNewLabel);

		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(AddFriendUI.class.getResource("/image/\u4FEE\u70BC2.png")));
		lblNewLabel_3.setBounds(0, 0, 487, 110);
		panel_2.add(lblNewLabel_3);

		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(AddFriendUI.class.getResource("/image/\u4FEE\u65393.png")));
		lblNewLabel_2.setBounds(0, 0, 507, 189);
		panel_1.add(lblNewLabel_2);

		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setBounds(5, 5, 512, 276);
		contentPane.add(lblNewLabel_4);
		lblNewLabel_4.setIcon(new ImageIcon(AddFriendUI.class.getResource("/image/\u4FEE\u6539\u5317\u4EAC2.png")));

	}

	public void ff(String z, String x) {
		label_3 = new Label(z);
		label_3.setBounds(107, 10, 144, 23);
		panel_2.add(label_3);

		label_4 = new Label(x);
		label_4.setBounds(106, 39, 134, 23);
		panel_2.add(label_4);

	}
}