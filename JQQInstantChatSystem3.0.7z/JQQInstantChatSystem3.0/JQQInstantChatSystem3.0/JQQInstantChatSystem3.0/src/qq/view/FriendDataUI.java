package qq.view;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import qq.sevice.UserManager;

public class FriendDataUI extends JFrame {

	private JPanel contentPane;
	int ownerId;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					PersonalData frame = new PersonalData();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
	}

	/**
	 * Create the frame.
	 */
	public FriendDataUI(int ownerid) {
		this.ownerId = ownerid;
		UserManager um = new UserManager();
		int a = ownerid;
		new MobileNoBorderFrameTool(this);
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 510, 603);
		this.setLocationRelativeTo(null);// 设置在屏幕中央显示
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 511, 45);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("\u4E2A\u4EBA\u8D44\u6599");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("微软雅黑", Font.BOLD, 18));
		lblNewLabel.setBounds(172, 0, 153, 45);
		panel.add(lblNewLabel);

		JButton zxhButton = new JButton("");
		zxhButton.setBounds(439, 0, 30, 30);
		panel.add(zxhButton);
		zxhButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setExtendedState(ICONIFIED);
			}
		});
		zxhButton.setIcon(new ImageIcon(FriendDataUI.class.getResource("/image/\u6700\u5C0F\u5316.png")));

		JButton closeButton = new JButton("");
		closeButton.setBounds(481, 0, 30, 30);
		panel.add(closeButton);
		closeButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		closeButton.setIcon(new ImageIcon(FriendDataUI.class.getResource("/image/\u5173\u95ED9.png")));

		JLabel headpritureJLabel = new JLabel("");
		headpritureJLabel
				.setIcon(new ImageIcon(FriendDataUI.class.getResource("/image/\u8D44\u6599\u80CC\u666F\u9876.png")));
		headpritureJLabel.setBounds(0, 0, 511, 45);
		panel.add(headpritureJLabel);

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 36, 511, 567);
		contentPane.add(panel_2);
		panel_2.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("\u7528\u6237ID\uFF1A");
		lblNewLabel_1.setFont(new Font("微软雅黑", Font.BOLD, 16));
		lblNewLabel_1.setBounds(60, 13, 70, 30);
		panel_2.add(lblNewLabel_1);

		JLabel lblNewLabel_3 = new JLabel("" + um.getQQname1(a).getID());
		lblNewLabel_3.setBounds(140, 14, 183, 30);
		panel_2.add(lblNewLabel_3);

		JLabel lblNewLabel_5 = new JLabel("\u6027  \u522B\uFF1A");
		lblNewLabel_5.setFont(new Font("微软雅黑", Font.BOLD, 16));
		lblNewLabel_5.setBounds(60, 69, 67, 30);
		panel_2.add(lblNewLabel_5);

		JLabel lblNewLabel_6 = new JLabel(um.getQQname1(a).getSex());
		lblNewLabel_6.setBounds(139, 70, 56, 30);
		panel_2.add(lblNewLabel_6);

		JLabel lblNewLabel_7 = new JLabel("\u5E74  \u9F84\uFF1A");
		lblNewLabel_7.setFont(new Font("微软雅黑", Font.BOLD, 16));
		lblNewLabel_7.setBounds(285, 69, 65, 30);
		panel_2.add(lblNewLabel_7);

		JLabel lblNewLabel_8 = new JLabel("age");
		lblNewLabel_8.setBounds(384, 68, 72, 34);
		panel_2.add(lblNewLabel_8);

		JLabel lblNewLabel_9 = new JLabel("\u751F  \u65E5\uFF1A");
		lblNewLabel_9.setFont(new Font("微软雅黑", Font.BOLD, 16));
		lblNewLabel_9.setBounds(60, 124, 61, 28);
		panel_2.add(lblNewLabel_9);

		JLabel lblNewLabel_10 = new JLabel(um.getQQname1(a).getAge());
		lblNewLabel_10.setBounds(140, 125, 72, 29);
		panel_2.add(lblNewLabel_10);

		JLabel lblNewLabel_11 = new JLabel("\u661F  \u5EA7\uFF1A");
		lblNewLabel_11.setFont(new Font("微软雅黑", Font.BOLD, 16));
		lblNewLabel_11.setBounds(285, 125, 65, 26);
		panel_2.add(lblNewLabel_11);

		JLabel lblNewLabel_12 = new JLabel(um.getQQname1(a).getConstellation());
		lblNewLabel_12.setBounds(372, 124, 84, 30);
		panel_2.add(lblNewLabel_12);

		JLabel lblNewLabel_13 = new JLabel("\u5C5E  \u6027\uFF1A");
		lblNewLabel_13.setFont(new Font("微软雅黑", Font.BOLD, 16));
		lblNewLabel_13.setBounds(60, 180, 67, 30);
		panel_2.add(lblNewLabel_13);

		JLabel lblNewLabel_14 = new JLabel(um.getQQname1(a).getShengxiao());
		lblNewLabel_14.setBounds(140, 182, 30, 28);
		panel_2.add(lblNewLabel_14);

		JLabel lblNewLabel_15 = new JLabel("\u8840  \u578B\uFF1A");
		lblNewLabel_15.setFont(new Font("微软雅黑", Font.BOLD, 16));
		lblNewLabel_15.setBounds(283, 180, 67, 30);
		panel_2.add(lblNewLabel_15);

		JLabel lblNewLabel_16 = new JLabel(um.getQQname1(a).getBloodType());
		lblNewLabel_16.setBounds(384, 181, 56, 30);
		panel_2.add(lblNewLabel_16);

		JLabel lblNewLabel_17 = new JLabel("\u4E2A\u6027\u7B7E\u540D\uFF1A");
		lblNewLabel_17.setFont(new Font("微软雅黑", Font.BOLD, 16));
		lblNewLabel_17.setBounds(31, 319, 83, 29);
		panel_2.add(lblNewLabel_17);

		JLabel lblNewLabel_18 = new JLabel(um.getQQname1(a).getSignature());
		lblNewLabel_18.setBounds(107, 317, 316, 34);
		panel_2.add(lblNewLabel_18);

		JLabel lblNewLabel_20 = new JLabel("\u5730  \u5740\uFF1A");
		lblNewLabel_20.setFont(new Font("微软雅黑", Font.BOLD, 16));
		lblNewLabel_20.setBounds(31, 255, 66, 25);
		panel_2.add(lblNewLabel_20);

		JLabel lblNewLabel_21 = new JLabel(um.getQQname1(a).getAddress());
		lblNewLabel_21.setBounds(107, 251, 334, 34);
		panel_2.add(lblNewLabel_21);

		JLabel lblNewLabel_22 = new JLabel("\u4E2A\u4EBA\u8BF4\u660E\uFF1A");
		lblNewLabel_22.setFont(new Font("微软雅黑", Font.BOLD, 16));
		lblNewLabel_22.setBounds(31, 380, 84, 27);
		panel_2.add(lblNewLabel_22);

		JLabel lblNewLabel_23 = new JLabel(um.getQQname1(a).getExplain());
		lblNewLabel_23.setBounds(107, 380, 324, 57);
		panel_2.add(lblNewLabel_23);

		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(
				FriendDataUI.class.getResource("/image/icons8-\u00E8\u0082\u0096\u00E5\u0083\u008F-30.png")));
		lblNewLabel_2.setBounds(20, 13, 30, 30);
		panel_2.add(lblNewLabel_2);

		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4
				.setIcon(new ImageIcon(FriendDataUI.class.getResource("/image/\u6027\u522B\u5C0F\u56FE\u6807.png")));
		lblNewLabel_4.setBounds(20, 69, 30, 30);
		panel_2.add(lblNewLabel_4);

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(FriendDataUI.class.getResource("/image/\u751F\u65E5\u56FE\u6807.png")));
		label.setBounds(20, 122, 30, 30);
		panel_2.add(label);

		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(FriendDataUI.class.getResource("/image/\u751F\u8096\u5C0F\u56FE\u6807.png")));
		label_1.setBounds(20, 180, 30, 30);
		panel_2.add(label_1);

		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(FriendDataUI.class.getResource("/image/\u5E74\u9F84\u5C0F\u56FE\u6807.png")));
		label_2.setBounds(245, 69, 30, 30);
		panel_2.add(label_2);

		JLabel label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon(FriendDataUI.class.getResource("/image/\u661F\u5EA7\u5C0F\u56FE\u6807.png")));
		label_3.setBounds(245, 122, 30, 30);
		panel_2.add(label_3);

		JLabel label_4 = new JLabel("");
		label_4.setIcon(new ImageIcon(FriendDataUI.class.getResource("/image/\u8840\u578B\u5C0F\u56FE\u6807.png")));
		label_4.setBounds(245, 180, 30, 30);
		panel_2.add(label_4);

		JLabel lblNewLabel_19 = new JLabel("");
		lblNewLabel_19.setIcon(new ImageIcon(FriendDataUI.class.getResource("/image/\u80CC\u666F.png")));
		lblNewLabel_19.setBounds(0, 10, 511, 557);
		panel_2.add(lblNewLabel_19);
	}

	// 修改资料
	public void popupAlter() {
		AmendUserUI auu = new AmendUserUI(ownerId);
		auu.setVisible(true);
		dispose();
	}

}
