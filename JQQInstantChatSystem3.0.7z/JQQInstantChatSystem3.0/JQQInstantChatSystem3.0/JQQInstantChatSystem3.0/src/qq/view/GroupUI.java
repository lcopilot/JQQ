package qq.view;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import qq.mode.Message;
import qq.sevice.ManageClientUI;
import qq.sevice.ManagerClientConServerThread;
import qq.sevice.UserManager;
import util.CloseUtil;
import util.MessageType;

public class GroupUI extends JFrame implements MouseListener {

	private JPanel contentPane;
	JPanel GroupChatpanel2;
	JLabel[] photoJLabel;
	ClientUI cu;
	String groupName;
	UserManager um = new UserManager();
	int groupId;
	int ownerId;
	int friendid;// 好友ID
	String friendName;;
	Message ms = new Message();
	JTextArea InputtextArea;
	JTextArea ShowtextArea;
	ObjectOutputStream oos;
	ObjectInputStream ois;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					GroupUI frame = new GroupUI("测试群", 4, 2);
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public GroupUI(String groupName, int groupId, int ownerId) {
		setIconImage(Toolkit.getDefaultToolkit().getImage(GroupUI.class.getResource("/image/\u5934\u50CF.jpg")));
		this.groupName = groupName;
		this.groupId = groupId;
		this.ownerId = ownerId;
		new MobileNoBorderFrameTool(this);
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 770, 660);
		contentPane = new JPanel();
		this.setLocationRelativeTo(null);// 设置在屏幕中央显示
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 770, 59);
		contentPane.add(panel);
		panel.setLayout(null);

		JButton zxhButton = new JButton("");
		zxhButton.setBounds(699, 0, 30, 30);
		panel.add(zxhButton);
		zxhButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				setExtendedState(ICONIFIED);
			}
		});
		zxhButton.setIcon(new ImageIcon(GroupUI.class.getResource("/image/\u6700\u5C0F\u5316 1.png")));

		JButton closeButton = new JButton("");
		closeButton.setBounds(740, 0, 30, 30);
		panel.add(closeButton);
		closeButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				dispose();
			}
		});
		closeButton.setIcon(new ImageIcon(GroupUI.class.getResource("/image/\u5173\u95ED1.png")));

		JLabel GroupNameJLabel = new JLabel("");
		GroupNameJLabel.setForeground(Color.WHITE);
		GroupNameJLabel.setFont(new Font("微软雅黑", Font.BOLD, 25));
		GroupNameJLabel.setText(groupName);
		GroupNameJLabel.setHorizontalAlignment(SwingConstants.CENTER);
		GroupNameJLabel.setBounds(255, 0, 281, 59);
		panel.add(GroupNameJLabel);

		JLabel backdropJLabel = new JLabel("");
		backdropJLabel.setIcon(new ImageIcon(GroupUI.class.getResource("/image/\u7FA4\u804A\u5934\u9876.png")));
		backdropJLabel.setBounds(0, 0, 770, 59);
		panel.add(backdropJLabel);

		JPanel GroupChatpanel = new JPanel();
		GroupChatpanel.setBounds(0, 61, 177, 599);
		contentPane.add(GroupChatpanel);
		GroupChatpanel.setLayout(null);

		JScrollPane GroupChatscrollPane = new JScrollPane();
		GroupChatscrollPane.setBounds(0, 35, 177, 564);
		GroupChatpanel.add(GroupChatscrollPane);

		GroupChatpanel2 = new JPanel();
		GroupChatscrollPane.setViewportView(GroupChatpanel2);
		GridBagLayout gbl_GroupChatpanel2 = new GridBagLayout();
		gbl_GroupChatpanel2.columnWidths = new int[] { 0 };
		gbl_GroupChatpanel2.rowHeights = new int[] { 0 };
		gbl_GroupChatpanel2.columnWeights = new double[] { Double.MIN_VALUE };
		gbl_GroupChatpanel2.rowWeights = new double[] { Double.MIN_VALUE };
		GroupChatpanel2.setLayout(new GridLayout(50, 1, 4, 4));

		JLabel GroupChatJLabel = new JLabel("\u7FA4\u6210\u5458");
		GroupChatJLabel.setBounds(0, 0, 177, 34);
		GroupChatpanel.add(GroupChatJLabel);
		GroupChatJLabel.setFont(new Font("微软雅黑", Font.BOLD, 20));
		GroupChatJLabel.setHorizontalAlignment(SwingConstants.CENTER);

		JLabel Label = new JLabel("");
		Label.setIcon(new ImageIcon(GroupUI.class.getResource("/image/\u6210\u54582.png")));
		Label.setBounds(0, 0, 177, 34);
		GroupChatpanel.add(Label);

		int groupMemberNumber = um.getgroupMemberNumber(groupId).getGroupmembernumber();
		photoJLabel = new JLabel[groupMemberNumber];
		for (int i = 0; i < photoJLabel.length; i++) {
			photoJLabel[i] = new JLabel(um.getgroupMemberName(groupId, i).getGroupmembername() + "",
					new ImageIcon(GroupUI.class.getResource("/image/头像.jpg")), JLabel.LEFT);
			photoJLabel[i].addMouseListener(this);
			GroupChatpanel2.add(photoJLabel[i]);
		}

		JPanel Showpane = new JPanel();
		Showpane.setBounds(178, 61, 592, 315);
		contentPane.add(Showpane);
		Showpane.setLayout(null);

		JScrollPane ShowscrollPane = new JScrollPane();
		ShowscrollPane.setBounds(0, 0, 592, 315);
		Showpane.add(ShowscrollPane);

		ShowtextArea = new JTextArea();
		ShowtextArea.setFont(new Font("微软雅黑", Font.BOLD, 18));
		ShowtextArea.setEditable(false);
		ShowscrollPane.setViewportView(ShowtextArea);

		JPanel Otherpanel = new JPanel();
		Otherpanel.setBounds(178, 377, 592, 44);
		contentPane.add(Otherpanel);
		Otherpanel.setLayout(null);

		JLabel priture1 = new JLabel("");
		priture1.setIcon(new ImageIcon(GroupUI.class.getResource("/image/\u7B11\u8138\u5C0F\u56FE\u6807.png")));
		priture1.setBounds(25, 8, 30, 30);
		Otherpanel.add(priture1);

		JLabel priture2 = new JLabel("");
		priture2.setIcon(new ImageIcon(GroupUI.class.getResource("/image/\u8BED\u97F3\u5C0F\u56FE\u6807.png")));
		priture2.setBounds(83, 8, 30, 30);
		Otherpanel.add(priture2);

		JLabel priture3 = new JLabel("");
		priture3.setIcon(new ImageIcon(GroupUI.class.getResource("/image/\u56FE\u7247\u5C0F\u56FE\u6807.png")));
		priture3.setBounds(142, 8, 30, 30);
		Otherpanel.add(priture3);

		JLabel priture4 = new JLabel("");
		priture4.setIcon(new ImageIcon(GroupUI.class.getResource("/image/\u5F55\u50CF\u5C0F\u56FE\u6807.png")));
		priture4.setBounds(200, 8, 30, 30);
		Otherpanel.add(priture4);

		JLabel priture5 = new JLabel("");
		priture5.setIcon(new ImageIcon(GroupUI.class.getResource("/image/\u622A\u56FE\u5C0F\u56FE\u6807.png")));
		priture5.setBounds(258, 8, 30, 30);
		Otherpanel.add(priture5);

		JLabel priture6 = new JLabel("");
		priture6.setIcon(new ImageIcon(GroupUI.class.getResource("/image/\u7535\u8BDD\u5C0F\u56FE\u6807.png")));
		priture6.setBounds(526, 8, 30, 30);
		Otherpanel.add(priture6);

		JLabel priture7 = new JLabel("");
		priture7.setIcon(new ImageIcon(GroupUI.class.getResource("/image/\u793C\u7269i\u5C0F\u56FE\u6807.png")));
		priture7.setBounds(471, 8, 30, 30);
		Otherpanel.add(priture7);

		JPanel Inputpanel = new JPanel();
		Inputpanel.setBounds(178, 422, 592, 197);
		contentPane.add(Inputpanel);
		Inputpanel.setLayout(null);

		JScrollPane InputscrollPane = new JScrollPane();
		InputscrollPane.setBounds(0, 0, 592, 197);
		Inputpanel.add(InputscrollPane);

		InputtextArea = new JTextArea();
		InputtextArea.setFont(new Font("微软雅黑", Font.BOLD, 18));
		InputscrollPane.setViewportView(InputtextArea);

		JButton CancealButton = new JButton("\u5173\u95ED");
		CancealButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		CancealButton.setFont(new Font("微软雅黑", Font.BOLD, 20));
		CancealButton.setBounds(375, 620, 113, 40);
		contentPane.add(CancealButton);

		JButton sendbutton = new JButton("\u53D1\u9001");
		sendbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendGroupMessage();
			}
		});
		sendbutton.setFont(new Font("微软雅黑", Font.BOLD, 20));
		sendbutton.setBounds(629, 620, 113, 40);
		contentPane.add(sendbutton);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		if (e.getClickCount() == 2) {
			// 得到私聊窗体
			// 得到好友昵称
			friendName = ((JLabel) e.getSource()).getText();
			friendid = um.getfriendQQ1(friendName).getFriendQQ();
			cu = new ClientUI(this.ownerId, friendName, friendid);
			// 把聊天界面加入到管理类中
			ManageClientUI.addClientUI(this.ownerId + " " + friendid, cu);
			cu.setVisible(true);
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		JLabel js = (JLabel) e.getSource();
		js.setForeground(Color.RED);
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		JLabel js = (JLabel) e.getSource();
		js.setForeground(Color.BLACK);
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	// 发送群消息
	public void sendGroupMessage() {
		// 如果用户点击了,发送按钮
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		ms = new Message();
		ms.setMesType(MessageType.Message_group);
		ms.setSendID(this.ownerId);
		ms.setRecevoirID(friendid);
		ms.setGroupId(groupId);
		ms.setMessageContenu(InputtextArea.getText());
		ms.setSendTime(sf.format(new Date()).toString());

		try {
			// 发送给服务器
			oos = new ObjectOutputStream(
					ManagerClientConServerThread.getClientConServerThread(ownerId).getS().getOutputStream());
			oos.writeObject(ms);
			this.ShowtextArea.append(sf.format(new Date()).toString() + "\n我: " + InputtextArea.getText() + "\n");
			this.InputtextArea.setText("");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			CloseUtil.closeAll(ois, oos);
			e.printStackTrace();
		}
	}

	// 显示群消息
	public void showMessage(Message ms) {
		String info = ms.getSendTime() + "\n" + um.getQQname(ms.getSendID()).getName() + ": " + ms.getMessageContenu()
				+ "\n";
		this.ShowtextArea.append(info);
	}

	class MobileNoBorderFrameTool {
		private Point OriginalPoint = null;
		private Point MobileDistance = null;
		private boolean isDraging = false;

		public MobileNoBorderFrameTool(final Component frame) {
			super();
			OriginalPoint = new Point();
			MobileDistance = new Point();
			frame.addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					isDraging = true;
					OriginalPoint.x = e.getX();
					OriginalPoint.y = e.getY();
				}

				public void mouseReleased(MouseEvent e) {
					isDraging = false;
				}

			});

			frame.addMouseMotionListener(new MouseMotionListener() {
				@Override
				public void mouseMoved(MouseEvent e) {
				}

				@Override
				public void mouseDragged(MouseEvent e) {
					if (isDraging) {
						MobileDistance = frame.getLocation();
						frame.setLocation(MobileDistance.x + e.getX() - OriginalPoint.x,
								MobileDistance.y + e.getY() - OriginalPoint.y);
					}

				}
			});
		}
	}
}
