package qq.view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

import qq.sevice.ServerManager;

/**
 * @author MuGe
 * @date ???????: 2019??6??22?? ????11:51:16
 * @version V1.0
 * @Project JQQInstantChatSystem3.0
 * @Package qq.view
 */
public class ServerUI extends JFrame {

	private JPanel contentPane;
	ServerManager sm;
	JTextArea textArea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ServerUI frame = new ServerUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ServerUI() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ServerUI.class.getResource("/image/\u5934\u50CF.jpg")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 652, 617);
		this.setLocationRelativeTo(null);// ????????????????
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton startButton = new JButton("\u542F  \u52A8");
		startButton.setFont(new Font("??????", Font.PLAIN, 18));
		startButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				sm = new ServerManager();
			}
		});
		startButton.setBounds(21, 162, 114, 48);
		contentPane.add(startButton);

		JButton closeButton = new JButton("\u5173  \u95ED");
		closeButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				final ActionListener login = this;
				// ????????

			}

		});

		closeButton.setFont(new Font("??????", Font.PLAIN, 18));
		closeButton.setBounds(21, 251, 114, 48);
		contentPane.add(closeButton);

		JLabel label = new JLabel("\u670D\u52A1\u5668");
		label.setFont(new Font("??????", Font.PLAIN, 36));
		label.setBounds(231, 10, 114, 41);
		contentPane.add(label);

		textArea = new JTextArea();
		textArea.setBounds(165, 130, 463, 440);
		contentPane.add(textArea);

		JLabel label_1 = new JLabel("\u4EFB\u52A1\u65E5\u5FD7");
		label_1.setFont(new Font("??????", Font.PLAIN, 18));
		label_1.setBounds(165, 86, 87, 34);
		contentPane.add(label_1);
	}

	public void jobLog(String s) {
		this.textArea.append(s);
	}
}
