package qq.view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Random;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import qq.mode.User;
import qq.sevice.ClientManager;
import qq.sevice.UserManager;
import util.HoroScope;

public class Register extends JFrame {

	private JPanel contentPane;
	private JTextField NameJTextField;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	JRadioButton ManJRadioButton;
	JRadioButton WomanJRadioButton;
	private JPasswordField PasswordField;
	private JPasswordField PasswordField2;
	JComboBox year_comboBoxyear;
	JComboBox month_comboBox;
	JComboBox day_comboBox;
	String strdate;

	LoginUI login = new LoginUI();
	UserManager um = new UserManager();
	User u;
	ObjectInputStream ois;
	ObjectOutputStream oos;
	ClientManager cm = new ClientManager();
	int radomInt;
	String strAddress;// 地址
	String strAge;// 年龄
	String strAnimal;// 生肖
	String strConstellation;// 星座
	String strBloodType;// 血型
	String strSignature;// 签名
	String strExplain;// 个人说明
	String strSex = "";// 性别
	String strName;// 昵称
	String strPSW;// 密码
	String strdate1;// 年
	String strdate2;// 月
	String strdate3;// 日
	String strdate4;// 获得出生年月
	private boolean result;
	private JTextField SignatextArea;
	private JButton closeButton;
	private JButton zxhButton;
	private JLabel backdropLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register frame = new Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Register() {
		new MobileNoBorderFrameTool(this);
		setUndecorated(true);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Register.class.getResource("/image/\u5934\u50CF.jpg")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 446, 656);
		this.setLocationRelativeTo(null);// 设置在屏幕中央显示
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel RegisterJLabel = new JLabel("           \u6CE8         \u518C    ");
		RegisterJLabel.setForeground(Color.WHITE);
		RegisterJLabel.setFont(new Font("微软雅黑", Font.BOLD, 30));
		RegisterJLabel.setBounds(59, 38, 329, 45);
		contentPane.add(RegisterJLabel);

		JLabel textNameJLabel = new JLabel("\u7528\u6237\u540D\uFF1A");
		textNameJLabel.setForeground(Color.WHITE);
		textNameJLabel.setFont(new Font("仿宋", Font.BOLD, 21));
		textNameJLabel.setBounds(23, 138, 122, 30);
		contentPane.add(textNameJLabel);

		NameJTextField = new JTextField();
		NameJTextField.setFont(new Font("微软雅黑", Font.PLAIN, 18));
		NameJTextField.setBounds(153, 139, 235, 30);
		contentPane.add(NameJTextField);
		NameJTextField.setColumns(10);

		JLabel PasswordJLabel = new JLabel("\u767B\u9646\u5BC6\u7801\uFF1A");
		PasswordJLabel.setForeground(Color.WHITE);
		PasswordJLabel.setFont(new Font("仿宋", Font.BOLD, 21));
		PasswordJLabel.setBounds(23, 200, 122, 45);
		contentPane.add(PasswordJLabel);

		JLabel PasswordJLabel2 = new JLabel("\u786E\u8BA4\u5BC6\u7801\uFF1A");
		PasswordJLabel2.setForeground(Color.WHITE);
		PasswordJLabel2.setFont(new Font("仿宋", Font.BOLD, 21));
		PasswordJLabel2.setBounds(23, 275, 122, 43);
		contentPane.add(PasswordJLabel2);

		JLabel SexJLabel = new JLabel("\u6027   \u522B\uFF1A");
		SexJLabel.setForeground(Color.WHITE);
		SexJLabel.setFont(new Font("仿宋", Font.BOLD, 25));
		SexJLabel.setBounds(23, 427, 122, 45);
		contentPane.add(SexJLabel);

		ManJRadioButton = new JRadioButton("\u7537");
		ManJRadioButton.setBackground(new Color(106, 90, 205));
		buttonGroup.add(ManJRadioButton);
		ManJRadioButton.setFont(new Font("仿宋", Font.BOLD, 25));
		ManJRadioButton.setBounds(153, 429, 68, 40);
		contentPane.add(ManJRadioButton);

		WomanJRadioButton = new JRadioButton("\u5973");
		WomanJRadioButton.setBackground(new Color(106, 90, 205));
		buttonGroup.add(WomanJRadioButton);
		WomanJRadioButton.setFont(new Font("仿宋", Font.BOLD, 25));
		WomanJRadioButton.setBounds(279, 429, 68, 40);
		contentPane.add(WomanJRadioButton);

		JLabel AgeJLabel = new JLabel("\u51FA\u751F\u65E5\u671F\uFF1A");
		AgeJLabel.setForeground(Color.WHITE);
		AgeJLabel.setFont(new Font("仿宋", Font.BOLD, 21));
		AgeJLabel.setBounds(23, 348, 111, 45);
		contentPane.add(AgeJLabel);

		JLabel Signature = new JLabel("\u7B7E   \u540D\uFF1A");
		Signature.setForeground(Color.WHITE);
		Signature.setFont(new Font("仿宋", Font.BOLD, 21));
		Signature.setBounds(23, 511, 111, 30);
		contentPane.add(Signature);

		JButton RegisterJButton = new JButton("\u6CE8   \u518C");
		RegisterJButton.setBorder(null);
		RegisterJButton.setForeground(Color.WHITE);
		RegisterJButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				RegisterJButton.setForeground(Color.BLACK);
			}

			@Override
			public void mouseExited(MouseEvent arg0) {
				RegisterJButton.setForeground(Color.WHITE);
			}
		});
		RegisterJButton.setBackground(new Color(0, 51, 255));

		RegisterJButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RegisterJButtonisteractionPerformed(e);
			}
		});
		RegisterJButton.setFont(new Font("微软雅黑", Font.PLAIN, 21));
		RegisterJButton.setBounds(35, 603, 133, 40);
		contentPane.add(RegisterJButton);

		JButton ResetJButton = new JButton("\u91CD   \u7F6E");
		ResetJButton.setBorder(null);
		ResetJButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				ResetJButton.setForeground(Color.BLACK);
			}

			@Override
			public void mouseExited(MouseEvent arg0) {
				ResetJButton.setForeground(Color.WHITE);
			}
		});
		ResetJButton.setForeground(Color.WHITE);
		ResetJButton.setBackground(new Color(0, 51, 255));
		ResetJButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ResetJButton(e);
			}
		});
		ResetJButton.setFont(new Font("微软雅黑", Font.PLAIN, 21));
		ResetJButton.setBounds(266, 603, 122, 40);
		contentPane.add(ResetJButton);

		PasswordField = new JPasswordField();
		PasswordField.setFont(new Font("微软雅黑", Font.PLAIN, 24));
		PasswordField.setBounds(153, 205, 235, 30);
		contentPane.add(PasswordField);

		PasswordField2 = new JPasswordField();
		PasswordField2.setFont(new Font("微软雅黑", Font.PLAIN, 24));
		PasswordField2.setBounds(153, 279, 235, 30);
		contentPane.add(PasswordField2);

		year_comboBoxyear = new JComboBox();
		year_comboBoxyear.setBackground(Color.WHITE);
		year_comboBoxyear.setFont(new Font("微软雅黑", Font.PLAIN, 14));
		year_comboBoxyear.setModel(new DefaultComboBoxModel(
				new String[] { "\u5E74", "1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999",
						"2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011",
						"2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019" }));
		year_comboBoxyear.setBounds(153, 355, 79, 34);
		contentPane.add(year_comboBoxyear);

		month_comboBox = new JComboBox();
		month_comboBox.setBackground(Color.WHITE);
		month_comboBox.setFont(new Font("微软雅黑", Font.PLAIN, 14));
		month_comboBox.setModel(new DefaultComboBoxModel(
				new String[] { "\u6708", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
		month_comboBox.setBounds(251, 355, 68, 34);
		contentPane.add(month_comboBox);

		day_comboBox = new JComboBox();
		day_comboBox.setBackground(Color.WHITE);
		day_comboBox.setFont(new Font("微软雅黑", Font.PLAIN, 14));
		day_comboBox.setModel(new DefaultComboBoxModel(new String[] { "\u65E5", "01", "02", "03", "04", "05", "06",
				"07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23",
				"24", "25", "26", "27", "28", "29", "30", "31" }));
		day_comboBox.setBounds(357, 357, 68, 30);
		contentPane.add(day_comboBox);

		SignatextArea = new JTextField();
		SignatextArea.setFont(new Font("微软雅黑", Font.PLAIN, 18));
		SignatextArea.setBounds(153, 512, 235, 30);
		contentPane.add(SignatextArea);
		SignatextArea.setColumns(10);

		closeButton = new JButton("");
		closeButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				dispose();
				LoginUI lu = new LoginUI();
				lu.setVisible(true);
			}
		});
		closeButton.setIcon(new ImageIcon(Register.class.getResource("/image/\u5173\u95ED1.png")));
		closeButton.setBounds(415, 0, 30, 30);
		contentPane.add(closeButton);

		zxhButton = new JButton("");
		zxhButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				setExtendedState(ICONIFIED);
			}
		});
		zxhButton.setIcon(new ImageIcon(Register.class.getResource("/image/\u6700\u5C0F\u5316 1.png")));
		zxhButton.setBounds(368, 0, 30, 30);
		contentPane.add(zxhButton);

		backdropLabel = new JLabel("");
		backdropLabel.setIcon(new ImageIcon(Register.class.getResource("/image/\u6CE8\u518C\u80CC\u666F.png")));
		backdropLabel.setBounds(0, 0, 445, 656);
		contentPane.add(backdropLabel);
	}

	public void RegisterJButtonisteractionPerformed(ActionEvent arg0) {

		boolean result = true;
		// 获取用户在界面上的输入
		// 获得用户输入的昵称
		strName = this.NameJTextField.getText().trim();
		// 获得用户输入的密码
		strPSW = this.PasswordField.getText().trim();
		// 判断两次密码是否输入一致
		if (!this.PasswordField2.getText().trim().equals(this.PasswordField.getText().trim())) {
			JOptionPane.showMessageDialog(null, "两次密码输入不一致！");
		} else {
			// 获得用户输入的性别

			if (this.ManJRadioButton.isSelected()) {
				strSex = this.ManJRadioButton.getText().trim();
			} else if (this.WomanJRadioButton.isSelected()) {
				strSex = this.WomanJRadioButton.getText().trim();
			}

			strdate1 = this.year_comboBoxyear.getSelectedItem().toString();// 获得年
			strdate2 = this.month_comboBox.getSelectedItem().toString();// 获得月
			strdate3 = this.day_comboBox.getSelectedItem().toString();// 获得日
			strdate = strdate1 + "-" + strdate2 + "-" + strdate3;

			strdate4 = strdate1 + strdate2 + strdate3;// 获得出生年月
			HoroScope a = new HoroScope();
			String b = a.oneDay1(strdate4);// 获得生肖
			String c = a.oneDay2(strdate4);// 获得星座

			// 获取生肖
			// 获取用户的地址
			strAddress = "-";
			// 获得用户年龄
			strAge = this.strdate;
			// 获得用户的生肖
			strAnimal = b;
			// 获得用户的星座
			strConstellation = c;
			// 获得用户的血型
			strBloodType = "-";
			// 获得用户签名
			strSignature = this.SignatextArea.getText().trim();
			// 获得用户的个人说明
			strExplain = "-";
			// 随机产生QQ号
			do {
				radomInt = new Random().nextInt(999999);// 产生随机数
				// 发送注册信息给服务器
				// sendRegister();
				this.result = sendRegister();
			} while (this.result);
		}
	}

	public boolean sendRegister() {
		boolean result = true;
		// 如果用户点击注册按钮
		u = new User();
		u.setID(radomInt);
		u.setName(strName);
		u.setPassword(strPSW);
		u.setSex(strSex);
		u.setAddress(strAddress);
		u.setAge(strAge);
		u.setShengxiao(strAnimal);
		u.setConstellation(strConstellation);
		u.setBloodType(strBloodType);
		u.setSignature(strSignature);
		u.setExplain(strExplain);
		u.setMark("2");
		int checkRegister = cm.CheckRegister(u);
		if (checkRegister == 4) {
			result = false;
			try {
				// 在对话框中显示用户输入的数据
				String msg = "请确认你的注册信息：";
				msg += "\nQQ:" + radomInt;
				msg += "\n输入昵称：" + strName;
				msg += "\n输入的密码：" + strPSW;
				msg += "\n性别：" + strSex;
				msg += "\n出生日期:" + strAge;
				msg += "\n生肖" + strAnimal;
				msg += "\n星座" + strConstellation;
				msg += "\n签名：" + strSignature;
				JOptionPane.showMessageDialog(null, msg);

				JOptionPane.showMessageDialog(null, "注册成功");
				// 关闭当前登入窗体，并且释放资源
				this.dispose();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			// 显示登入窗体
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						login.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		} else if (checkRegister == 5) {
			result = false;
			JOptionPane.showMessageDialog(null, "该用户名已存在!");
		}

		return result;
	}

	public void ResetJButton(ActionEvent a) {
		this.NameJTextField.setText(""); // 清空昵称
		this.PasswordField.setText(""); // 清空密码
		this.PasswordField2.setText("");
		buttonGroup.clearSelection(); // 清除性别

		this.SignatextArea.setText(""); // 清空签名
		this.year_comboBoxyear.setSelectedIndex(0);// 使年回到第一个
		this.month_comboBox.setSelectedIndex(0);// 使月份回到第一个
		this.day_comboBox.setSelectedIndex(0);// 使日回到第一个

	}
}
