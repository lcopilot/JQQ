package qq.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import qq.mode.User;
import qq.sevice.UserManager;
import util.HoroScope;

public class AmendUserUI extends JFrame {

	private JPanel contentPane;
	private JTextField NametextField;
	private JTextField textField;
	User u;
	JComboBox SexcomboBox;
	JComboBox day_comboBox;
	JComboBox year_comboBoxyear;
	JComboBox month_comboBox;
	String strdate;
	JComboBox BloodytpecomboBox;
	JTextArea textArea;
	JTextArea textArea_1;
	String strAddress;// 地址
	String strAge;// 年龄
	String strAnimal;// 生肖
	String strConstellation;// 星座
	String strBloodType;// 血型
	String strSignature;// 签名
	String strExplain;// 个人说明
	String strSex = "";// 性别
	String strName;// 昵称
	String strSet;// 性别
	UserManager um = new UserManager();
	int ownerId;
	int a;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

	}

	/**
	 * Create the frame.
	 */
	public AmendUserUI(int ownerId) {
		setIconImage(Toolkit.getDefaultToolkit().getImage(AmendUserUI.class.getResource("/image/\u5934\u50CF.jpg")));
		this.ownerId = ownerId;
		a = ownerId;
		setUndecorated(true);
		new MobileNoBorderFrameTool(this);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 501, 598);
		this.setLocationRelativeTo(null);// 设置在屏幕中央显示
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 499, 40);
		contentPane.add(panel);
		panel.setLayout(null);

		JButton zxhButton = new JButton("");
		zxhButton.setBounds(425, 0, 30, 30);
		panel.add(zxhButton);
		zxhButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setExtendedState(ICONIFIED);
			}
		});
		zxhButton.setIcon(new ImageIcon(AmendUserUI.class.getResource("/image/\u6700\u5C0F\u5316.png")));

		JButton closeButton = new JButton("");
		closeButton.setBounds(469, 0, 30, 30);
		panel.add(closeButton);
		closeButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		closeButton.setIcon(new ImageIcon(AmendUserUI.class.getResource("/image/\u5173\u95ED - \u526F\u672C.png")));

		JLabel lblNewLabel = new JLabel("\u4FEE\u6539\u8D44\u6599");
		lblNewLabel.setBounds(201, 0, 140, 40);
		panel.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("微软雅黑", Font.BOLD, 18));

		JLabel headJLabel = new JLabel("");
		headJLabel.setIcon(new ImageIcon(AmendUserUI.class.getResource("/image/\u8D44\u6599\u80CC\u666F\u9876.png")));
		headJLabel.setBounds(0, 0, 499, 40);
		panel.add(headJLabel);

		JPanel panel_3 = new JPanel();
		panel_3.setBounds(0, 40, 499, 557);
		contentPane.add(panel_3);
		panel_3.setLayout(null);

		JLabel NameJLabel = new JLabel("\u7528\u6237\u540D\uFF1A");
		NameJLabel.setFont(new Font("微软雅黑", Font.BOLD, 16));
		NameJLabel.setBounds(29, 14, 67, 29);
		panel_3.add(NameJLabel);

		NametextField = new JTextField(um.getQQname1(a).getName());
		NametextField.setFont(new Font("微软雅黑", Font.BOLD, 16));
		NametextField.setBounds(120, 14, 135, 29);
		panel_3.add(NametextField);
		NametextField.setColumns(10);

		JLabel SexJLabel = new JLabel("\u6027  \u522B\uFF1A");
		SexJLabel.setFont(new Font("微软雅黑", Font.BOLD, 16));
		SexJLabel.setBounds(308, 15, 61, 26);
		panel_3.add(SexJLabel);

		SexcomboBox = new JComboBox();
		SexcomboBox.setFont(new Font("微软雅黑", Font.BOLD, 16));
		SexcomboBox.setModel(new DefaultComboBoxModel(new String[] { "\u7537", "\u5973" }));
		SexcomboBox.setBounds(388, 14, 48, 28);
		panel_3.add(SexcomboBox);

		JLabel BrithdayJLabel = new JLabel("\u51FA\u751F\u65E5\u671F\uFF1A");
		BrithdayJLabel.setFont(new Font("微软雅黑", Font.BOLD, 16));
		BrithdayJLabel.setBounds(29, 79, 86, 26);
		panel_3.add(BrithdayJLabel);

		year_comboBoxyear = new JComboBox();
		year_comboBoxyear.setFont(new Font("微软雅黑", Font.BOLD, 16));
		year_comboBoxyear.setModel(new DefaultComboBoxModel(
				new String[] { "\u5E74", "1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999",
						"2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011",
						"2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019" }));
		year_comboBoxyear.setBounds(120, 80, 70, 24);
		panel_3.add(year_comboBoxyear);

		month_comboBox = new JComboBox();
		month_comboBox.setFont(new Font("微软雅黑", Font.BOLD, 16));
		month_comboBox.setModel(new DefaultComboBoxModel(
				new String[] { "\u6708", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
		month_comboBox.setBounds(200, 80, 55, 24);
		panel_3.add(month_comboBox);

		day_comboBox = new JComboBox();
		day_comboBox.setFont(new Font("微软雅黑", Font.BOLD, 16));
		day_comboBox.setModel(new DefaultComboBoxModel(new String[] { "\u65E5", "01", "02", "03", "04", "05", "06",
				"07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23",
				"24", "25", "26", "27", "28", "29", "30", "31" }));
		day_comboBox.setBounds(277, 80, 55, 24);
		panel_3.add(day_comboBox);

		JLabel BloodtypeJLabel = new JLabel("\u8840  \u578B\uFF1A");
		BloodtypeJLabel.setFont(new Font("微软雅黑", Font.BOLD, 16));
		BloodtypeJLabel.setBounds(29, 136, 61, 29);
		panel_3.add(BloodtypeJLabel);

		BloodytpecomboBox = new JComboBox();
		BloodytpecomboBox.setFont(new Font("微软雅黑", Font.BOLD, 16));
		BloodytpecomboBox.setModel(new DefaultComboBoxModel(
				new String[] { "-", "A\u578B", "B\u578B", "O\u578B", "AB\u578B", "\u5176\u4ED6\u8840\u578B" }));
		BloodytpecomboBox.setBounds(120, 138, 109, 24);
		panel_3.add(BloodytpecomboBox);

		JLabel PersonageJLabel = new JLabel("\u4E2A\u4EBA\u8BF4\u660E\uFF1A");
		PersonageJLabel.setFont(new Font("微软雅黑", Font.BOLD, 16));
		PersonageJLabel.setBounds(10, 382, 84, 28);
		panel_3.add(PersonageJLabel);

		JScrollPane PersonagescrollPane = new JScrollPane();
		PersonagescrollPane.setBounds(120, 283, 330, 29);
		panel_3.add(PersonagescrollPane);

		textArea = new JTextArea(um.getQQname1(a).getAddress());
		textArea.setFont(new Font("微软雅黑", Font.BOLD, 16));
		PersonagescrollPane.setViewportView(textArea);

		JLabel AddressJLabel = new JLabel("\u5730  \u5740\uFF1A");
		AddressJLabel.setFont(new Font("微软雅黑", Font.BOLD, 16));
		AddressJLabel.setBounds(29, 284, 61, 28);
		panel_3.add(AddressJLabel);

		JScrollPane AddressscrollPane = new JScrollPane();
		AddressscrollPane.setBounds(120, 361, 316, 81);
		panel_3.add(AddressscrollPane);

		textArea_1 = new JTextArea(um.getQQname1(a).getExplain());
		AddressscrollPane.setViewportView(textArea_1);
		textArea_1.setFont(new Font("微软雅黑", Font.BOLD, 16));

		JButton ConfirmButton = new JButton("\u786E\u8BA4\u4FEE\u6539");
		ConfirmButton.setBackground(Color.WHITE);
		ConfirmButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == e.BUTTON1) {
					alterMessage(a);
					if ((um.setmessage(u, 12345)) > -1) {
						JOptionPane.showMessageDialog(null, "修改成功");
						UserDataUI udu = new UserDataUI(ownerId);
						udu.setVisible(true);

						dispose();
					} else {
						JOptionPane.showMessageDialog(null, "请检查你的输入是否有误");
					}

				}
			}
		});
		ConfirmButton.setFont(new Font("微软雅黑", Font.BOLD, 16));
		ConfirmButton.setBounds(192, 494, 113, 27);
		panel_3.add(ConfirmButton);

		JLabel lblNewLabel_1 = new JLabel("\u4E2A\u6027\u7B7E\u540D");
		lblNewLabel_1.setFont(new Font("微软雅黑", Font.BOLD, 15));
		lblNewLabel_1.setBounds(29, 207, 75, 26);
		panel_3.add(lblNewLabel_1);

		textField = new JTextField(um.getQQname1(a).getSignature());
		textField.setFont(new Font("微软雅黑", Font.BOLD, 16));
		textField.setBounds(120, 207, 330, 29);
		panel_3.add(textField);
		textField.setColumns(10);

		JLabel backdropJLabel = new JLabel("");
		backdropJLabel.setBounds(0, 0, 499, 559);
		panel_3.add(backdropJLabel);
		backdropJLabel.setIcon(new ImageIcon(AmendUserUI.class.getResource("/image/\u80CC\u666F2.png")));
	}

	// 修改资料
	public void alterMessage(int a) {
		// 获得用户
		strName = NametextField.getText().trim();
		// 获得性别
		strSet = SexcomboBox.getSelectedItem().toString();
		// 获得出身日期

		String strdate1 = year_comboBoxyear.getSelectedItem().toString();
		String strdate2 = month_comboBox.getSelectedItem().toString();
		String strdate3 = day_comboBox.getSelectedItem().toString();
		strdate = strdate1 + "-" + strdate2 + "-" + strdate3;
		String strdate4 = strdate1 + strdate2 + strdate3;
		HoroScope d = new HoroScope();
		String b = d.oneDay1(strdate4);// 获得生肖
		String c = d.oneDay2(strdate4);// 获得星座
		// 获得用户出身日期
		strAge = strdate;
		// 获得用户的生肖
		strAnimal = b;
		// 获得用户的星座
		strConstellation = c;
		// 获得血型
		strBloodType = BloodytpecomboBox.getSelectedItem().toString();
		// 获得个性签名
		strSignature = textField.getText().trim();
		// 获得地址
		strAddress = textArea.getText().trim();
		// 获得个人说明
		strExplain = textArea_1.getText().trim();

		// 如果用户点击修改按钮
		u = new User();
		u.setName(strName);
		u.setSex(strSet);
		u.setAge(strdate);
		u.setAddress(strAddress);
		u.setAge(strAge);
		u.setShengxiao(strAnimal);
		u.setConstellation(strConstellation);
		u.setBloodType(strBloodType);
		u.setSignature(strSignature);
		u.setExplain(strExplain);
		um.setmessage(u, a);
	}

}
