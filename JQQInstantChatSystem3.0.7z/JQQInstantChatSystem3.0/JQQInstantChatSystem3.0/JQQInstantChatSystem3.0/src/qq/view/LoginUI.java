package qq.view;

import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.ObjectOutputStream;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import qq.mode.Message;
import qq.mode.User;
import qq.sevice.ClientManager;
import qq.sevice.ManageFriendList;
import qq.sevice.ManagerClientConServerThread;
import util.CloseUtil;
import util.Verificationcode;

/**
 * @author MuGe
 * @date ???????: 2019??6??22?? ????11:51:02
 * @version V1.0
 * @Project JQQInstantChatSystem3.0
 * @Package qq.view
 */

public class LoginUI extends JFrame {

	private JPanel contentPane;
	private JTextField txtName;
	private JPasswordField PasswordField;
	private JTextField VerifyTextField;
	String code;
	JLabel lbl;
	ClientManager cm = new ClientManager();
	MainUI mu;
	User u = new User();
	ObjectOutputStream oos;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginUI frame = new LoginUI();
					frame.setVisible(true);
				} catch (Exception e) {

					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginUI() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(LoginUI.class.getResource("/image/\u5934\u50CF.jpg")));
		setUndecorated(true);
		new MobileNoBorderFrameTool(this);
		setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 916, 545);
		this.setLocationRelativeTo(null);// ????????????????
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel LoginJLabel = new JLabel("\u8D26   \u53F7\uFF1A");
		LoginJLabel.setForeground(Color.CYAN);
		LoginJLabel.setFont(new Font("??????", Font.BOLD, 25));
		LoginJLabel.setBounds(236, 145, 120, 40);
		contentPane.add(LoginJLabel);

		JLabel PswJLabel = new JLabel("\u5BC6   \u7801\uFF1A");
		PswJLabel.setForeground(Color.CYAN);
		PswJLabel.setFont(new Font("??????", Font.BOLD, 25));
		PswJLabel.setBounds(236, 228, 120, 36);
		contentPane.add(PswJLabel);

		txtName = new JTextField();
		txtName.setBackground(Color.WHITE);
		txtName.setFont(new Font("??????", Font.BOLD, 18));
		txtName.setBounds(370, 148, 256, 40);
		txtName.setBorder(null);
		contentPane.add(txtName);
		txtName.setColumns(10);

		JButton LoginButton = new JButton("\u767B  \u5F55");
		LoginButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				LoginButton.setForeground(Color.BLACK);
			}

			@Override
			public void mouseExited(MouseEvent arg0) {
				LoginButton.setForeground(Color.WHITE);
			}
		});
		LoginButton.setBackground(new Color(51, 153, 255));
		LoginButton.setForeground(Color.WHITE);
		LoginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loginEvent();
			}
		});
		LoginButton.setFont(new Font("????", Font.BOLD, 25));
		LoginButton.setBounds(136, 429, 192, 50);
		LoginButton.setBorder(null);
		contentPane.add(LoginButton);

		JButton btnNewButton_1 = new JButton("\u6CE8  \u518C");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				btnNewButton_1.setForeground(Color.BLACK);
			}

			@Override
			public void mouseExited(MouseEvent arg0) {
				btnNewButton_1.setForeground(Color.WHITE);
			}
		});
		btnNewButton_1.setBackground(new Color(51, 153, 255));
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final ActionListener login = this;
				// ?????????
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Register rs = new Register();
							rs.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				// ??????????
				setVisible(false);
			}

		});
		btnNewButton_1.setFont(new Font("????", Font.BOLD, 25));
		btnNewButton_1.setBounds(580, 429, 192, 50);
		btnNewButton_1.setBorder(null);
		contentPane.add(btnNewButton_1);

		PasswordField = new JPasswordField();
		PasswordField.setBackground(Color.WHITE);
		PasswordField.setFont(new Font("??????", Font.BOLD, 35));
		PasswordField.setBounds(370, 228, 256, 40);
		PasswordField.setBorder(null);
		contentPane.add(PasswordField);

		JLabel VerifyJLabel = new JLabel("\u9A8C\u8BC1\u7801\uFF1A");
		VerifyJLabel.setForeground(Color.CYAN);
		VerifyJLabel.setFont(new Font("??????", Font.BOLD, 25));
		VerifyJLabel.setBounds(236, 312, 120, 33);
		contentPane.add(VerifyJLabel);

		VerifyTextField = new JTextField();
		VerifyTextField.setBackground(Color.WHITE);
		VerifyTextField.setFont(new Font("??????", Font.BOLD, 24));
		VerifyTextField.setBounds(370, 309, 165, 40);
		VerifyTextField.setBorder(null);
		contentPane.add(VerifyTextField);
		VerifyTextField.setColumns(10);

		JPanel VerifyJphotoPanel = new JPanel();
		VerifyJphotoPanel.setBorder(null);
		VerifyJphotoPanel.setBackground(new Color(0, 102, 204));
		VerifyJphotoPanel.setForeground(new Color(0, 0, 0));
		VerifyJphotoPanel.setBorder(null);
		Object[] object = Verificationcode.createImage();
		// ?????????????
		code = object[0].toString();
		Icon img = new ImageIcon((BufferedImage) object[1]);
		VerifyJphotoPanel.setBounds(564, 298, 160, 50);
		contentPane.add(VerifyJphotoPanel);
		lbl = new JLabel();
		lbl.setBackground(Color.CYAN);
		VerifyJphotoPanel.add(lbl);
		lbl.setIcon(img);

		JButton closejbt = new JButton("");
		closejbt.setForeground(Color.WHITE);
		closejbt.setIcon(new ImageIcon(LoginUI.class.getResource("/image/\u5173\u95ED1.png")));
		closejbt.setBackground(Color.WHITE);
		closejbt.setBorder(null);
		closejbt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});

		closejbt.setBounds(886, 0, 30, 30);
		contentPane.add(closejbt);

		JButton Minjbtm = new JButton("");
		Minjbtm.setIcon(new ImageIcon(LoginUI.class.getResource("/image/\u6700\u5C0F\u5316 1.png")));
		Minjbtm.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setExtendedState(ICONIFIED);
			}
		});
		Minjbtm.setBounds(842, 0, 30, 30);
		contentPane.add(Minjbtm);
		Minjbtm.setBorder(null);
		Minjbtm.setForeground(Color.WHITE);
		Minjbtm.setBackground(Color.WHITE);

		JLabel comeJLabel = new JLabel("\u6B22   \u8FCE   \u4F7F   \u7528");
		comeJLabel.setForeground(Color.WHITE);
		comeJLabel.setHorizontalAlignment(SwingConstants.CENTER);
		comeJLabel.setFont(new Font("??????", Font.ITALIC, 30));
		comeJLabel.setBounds(0, 43, 916, 72);
		contentPane.add(comeJLabel);

		JLabel backdropJLabe = new JLabel("");
		backdropJLabe.setIcon(new ImageIcon(LoginUI.class.getResource("/image/QQ\u80CC\u666F.png")));
		backdropJLabe.setBounds(0, 0, 916, 545);
		contentPane.add(backdropJLabe);

		lbl.addMouseListener(new MouseAdapter() {
			@Override
			// ????????
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 1) {
					Object[] object = Verificationcode.createImage();
					code = object[0].toString();
					Icon img = new ImageIcon((BufferedImage) object[1]);
					lbl.setIcon(img);
					VerifyJphotoPanel.add(lbl);

				}
			}
		});

	}

	public void loginEvent() {
		// ??????????????????
		// ????????????????
		int strName = Integer.parseInt(this.txtName.getText().trim());
		// ???????
		String strPsw = this.PasswordField.getText().trim();
		// ????????
		String strCode = this.VerifyTextField.getText().trim();
		User u = new User();
		u.setID(strName);
		u.setPassword(strPsw);
		u.setMark("1");// ?????????????

		if (strCode.equalsIgnoreCase(code)) {
			int checkUser = cm.CheckUser(u);
			if (checkUser == 1) {
				JOptionPane.showMessageDialog(this, "??????!");
				try {
					// ???????????
					mu = new MainUI(u.getID());
					ManageFriendList.addFriendList(u.getID(), mu);
					// ???????????????????????
					oos = new ObjectOutputStream(
							ManagerClientConServerThread.getClientConServerThread(u.getID()).getS().getOutputStream());
					// ?????Message
					Message ms = new Message();
					ms.setMesType(util.MessageType.message_get_onLineFriend);
					// ????????QQ????????????
					ms.setSendID(u.getID());
					oos.writeObject(ms);

				} catch (Exception e) {
					CloseUtil.closeAll(oos);
					e.printStackTrace();
				}

				mu.setVisible(true);
				// ?????????
				this.dispose();
			}
			if (checkUser == 3) {
				JOptionPane.showMessageDialog(this, "?????????!");
			}
			if (checkUser == 2) {

				JOptionPane.showMessageDialog(this, "???????!");
			}
		} else {
			JOptionPane.showMessageDialog(this, "????????!");
		}
	}
}

class MobileNoBorderFrameTool {
	private Point OriginalPoint = null;
	private Point MobileDistance = null;
	private boolean isDraging = false;

	public MobileNoBorderFrameTool(final Component frame) {
		super();
		OriginalPoint = new Point();
		MobileDistance = new Point();
		frame.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				isDraging = true;
				OriginalPoint.x = e.getX();
				OriginalPoint.y = e.getY();
			}

			public void mouseReleased(MouseEvent e) {
				isDraging = false;
			}

		});

		frame.addMouseMotionListener(new MouseMotionListener() {
			@Override
			public void mouseMoved(MouseEvent e) {
			}

			@Override
			public void mouseDragged(MouseEvent e) {
				if (isDraging) {
					MobileDistance = frame.getLocation();
					frame.setLocation(MobileDistance.x + e.getX() - OriginalPoint.x,
							MobileDistance.y + e.getY() - OriginalPoint.y);
				}

			}
		});
	}
}
